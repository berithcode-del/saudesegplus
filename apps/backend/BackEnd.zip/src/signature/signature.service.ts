import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

@Injectable()
export class SignatureService {
  constructor(private readonly prisma: PrismaService) {}

  async generateLink(examRequestId: string, doctorId: string) {
    const request = await this.prisma.examRequest.findUnique({ where: { id: examRequestId } });
    if (!request) throw new NotFoundException('ExamRequest não encontrado');

    const asoDoc = await this.prisma.asoDocument.create({
      data: {
        requestId: examRequestId,
        doctorId,
        decision: 'PENDENTE',
        signatureProviderId: `mock_provider_${Date.now()}`,
      },
    });

    return {
      url: `/api/signature/sign/${asoDoc.id}`,
      asoDocumentId: asoDoc.id,
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
    };
  }

  async signDocument(asoDocumentId: string) {
    const doc = await this.prisma.asoDocument.findUnique({ where: { id: asoDocumentId } });
    if (!doc) throw new NotFoundException('Documento não encontrado');

    const updated = await this.prisma.asoDocument.update({
      where: { id: asoDocumentId },
      data: { signedAt: new Date() },
    });

    return { success: true, signedAt: updated.signedAt };
  }

  async handleWebhook(payload: { document_id: string; signed_at: string }) {
    await this.prisma.asoDocument.update({
      where: { id: payload.document_id },
      data: { signedAt: new Date(payload.signed_at) },
    });
    console.log(`[Webhook] Documento ${payload.document_id} assinado em ${payload.signed_at}`);
    return { success: true };
  }
}
