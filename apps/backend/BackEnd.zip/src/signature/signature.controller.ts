import { Controller, Post, Body, Param } from '@nestjs/common';
import { SignatureService } from './signature.service';

@Controller('api/signature')
export class SignatureController {
  constructor(private readonly signatureService: SignatureService) {}

  @Post('generate')
  async generateLink(@Body() body: { examRequestId: string; doctorId: string }) {
    const result = await this.signatureService.generateLink(body.examRequestId, body.doctorId);
    return { success: true, url: result.url, asoDocumentId: result.asoDocumentId, expiresAt: result.expiresAt };
  }

  @Post('sign/:id')
  async signDocument(@Param('id') id: string) {
    return this.signatureService.signDocument(id);
  }

  @Post('webhook')
  async handleWebhook(@Body() payload: { document_id: string; signed_at: string }) {
    return this.signatureService.handleWebhook(payload);
  }
}