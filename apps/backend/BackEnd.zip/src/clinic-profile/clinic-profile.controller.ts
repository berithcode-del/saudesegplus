import { Controller, Get, Patch, Body, UseGuards, Request } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { PrismaService } from '../prisma.service';

@UseGuards(JwtAuthGuard)
@Controller('api/clinic')
export class ClinicProfileController {
  constructor(private prisma: PrismaService) {}

  // GET /api/clinic/profile — Get own profile data
  @Get('profile')
  async getProfile(@Request() req: any) {
    const userId = req.user.sub;
    const user = await this.prisma.userAccount.findUnique({
      where: { id: userId },
      include: { clinicProfile: true },
    });
    if (!user?.clinicProfile) {
      return null;
    }
    return {
      id: user.clinicProfile.id,
      name: user.clinicProfile.name,
      cnpj: user.clinicProfile.cnpj,
      address: user.clinicProfile.address,
      city: user.clinicProfile.city,
      state: user.clinicProfile.state,
      phone: user.clinicProfile.phone,
      contactEmail: user.clinicProfile.contactEmail,
      email: user.email,
    };
  }

  @Patch('profile')
  async updateProfile(@Request() req: any, @Body() body: { name?: string; address?: string; city?: string; state?: string; phone?: string; contactEmail?: string }) {
    const userId = req.user.sub;
    const user = await this.prisma.userAccount.findUnique({
      where: { id: userId },
      include: { clinicProfile: true },
    });
    if (!user?.clinicProfile) {
      return { success: false, message: 'Perfil de clínica não encontrado' };
    }
    await this.prisma.clinic.update({
      where: { id: user.clinicProfile.id },
      data: {
        ...(body.name !== undefined ? { name: body.name } : {}),
        ...(body.address !== undefined ? { address: body.address } : {}),
        ...(body.city !== undefined ? { city: body.city } : {}),
        ...(body.state !== undefined ? { state: body.state } : {}),
        ...(body.phone !== undefined ? { phone: body.phone } : {}),
        ...(body.contactEmail !== undefined ? { contactEmail: body.contactEmail } : {}),
      },
    });
    return { success: true };
  }
}