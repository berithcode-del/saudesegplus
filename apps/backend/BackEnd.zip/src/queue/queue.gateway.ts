import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  OnGatewayConnection,
  OnGatewayDisconnect,
  MessageBody,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { UseGuards } from '@nestjs/common';
import { WsJwtGuard } from '../auth/ws-jwt.guard';

@WebSocketGateway({
  cors: {
    origin: '*',
  },
})
@UseGuards(WsJwtGuard)
export class QueueGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server: Server;

  handleConnection(client: Socket) {
    console.log(`Client connected: ${client.id}`);
  }

  handleDisconnect(client: Socket) {
    console.log(`Client disconnected: ${client.id}`);
  }

  // Emite para todos os clientes quando status de um paciente muda
  emitQueueUpdate(event: string, payload: object) {
    this.server.emit(event, payload);
  }

  @SubscribeMessage('doctor_online')
  handleDoctorOnline(@MessageBody() data: { doctorId: string }) {
    this.server.emit('doctor_status', { doctorId: data.doctorId, status: 'online' });
  }
}
