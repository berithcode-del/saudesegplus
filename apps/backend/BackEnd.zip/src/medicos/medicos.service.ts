import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { paginate, PaginatedResult } from '../common/pagination';

@Injectable()
export class MedicosService {
  constructor(private readonly prisma: PrismaService) {}

  async list(
    filters: { search?: string; city?: string; state?: string },
    page: number = 1,
    limit: number = 20,
  ): Promise<PaginatedResult<any>> {
    const where: any = {
      OR: filters.search
        ? [
            { name: { contains: filters.search, mode: 'insensitive' } },
            { crmNumber: { contains: filters.search, mode: 'insensitive' } },
            { specialties: { contains: filters.search, mode: 'insensitive' } },
          ]
        : undefined,
      city: filters.city,
      state: filters.state,
      verifiedAt: { not: null },
    };
    return paginate(this.prisma.doctor, page, limit, {
      where,
      select: {
        id: true,
        name: true,
        crmNumber: true,
        crmState: true,
        city: true,
        state: true,
        specialties: true,
        status: true,
      },
      orderBy: { name: 'asc' },
    });
  }

  async getProfile(doctorId: string) {
    const doctor = await this.prisma.doctor.findUnique({
      where: { id: doctorId },
      select: {
        id: true,
        name: true,
        crmNumber: true,
        crmState: true,
        specialties: true,
        status: true,
      },
    });

    if (!doctor) {
      throw new NotFoundException('Médico não encontrado');
    }

    return doctor;
  }

  async listSolicitacoes(doctorId: string, startDate?: string, endDate?: string) {
    const doctor = await this.prisma.doctor.findUnique({
      where: { id: doctorId },
    });

    if (!doctor) {
      throw new NotFoundException('Médico não encontrado');
    }

    const whereQueue: any = {
      assignedDoctorId: doctorId,
    };

    if (startDate || endDate) {
      whereQueue.assignedAt = {};
      if (startDate) {
        whereQueue.assignedAt.gte = new Date(startDate);
      }
      if (endDate) {
        whereQueue.assignedAt.lte = new Date(endDate);
      }
    }

    const queueEntries = await this.prisma.queueEntry.findMany({
      where: whereQueue,
      include: {
        request: {
          include: {
            patient: true,
            clinic: true,
            invite: { include: { company: true } },
            results: { include: { type: true } },
            asoDocuments: true,
          },
        },
      },
      orderBy: { assignedAt: 'desc' },
    });

    return queueEntries
      .filter((entry) => entry.request)
      .map((entry) => ({
        ...entry.request,
        queueStatus: entry.status,
        enteredQueueAt: entry.enteredQueueAt,
        assignedAt: entry.assignedAt,
      }));
  }
}
