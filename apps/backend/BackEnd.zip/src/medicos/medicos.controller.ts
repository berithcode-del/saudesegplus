import { Controller, Get, Param, Query } from '@nestjs/common';
import { MedicosService } from './medicos.service';
import { Public } from '../auth/decorators/public.decorator';

@Controller('api/medicos')
export class MedicosController {
  constructor(private readonly medicosService: MedicosService) {}

  @Public()
  @Get()
  async list(
    @Query('search') search?: string,
    @Query('city') city?: string,
    @Query('state') state?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    const data = await this.medicosService.list(
      { search, city, state },
      page ? parseInt(page, 10) : 1,
      limit ? parseInt(limit, 10) : 20,
    );
    return { success: true, data };
  }

  @Public()
  @Get(':id/perfil')
  async getProfile(@Param('id') doctorId: string) {
    const data = await this.medicosService.getProfile(doctorId);
    return { success: true, data };
  }

  @Public()
  @Get(':id/solicitacoes')
  async listSolicitacoes(
    @Param('id') doctorId: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
  ) {
    const data = await this.medicosService.listSolicitacoes(doctorId, startDate, endDate);
    return { success: true, data };
  }
}
