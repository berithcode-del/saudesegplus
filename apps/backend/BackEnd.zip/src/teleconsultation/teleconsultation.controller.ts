import { Controller, Post, Body, BadRequestException, NotImplementedException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { Public } from '../auth/decorators/public.decorator';

@Controller('api/teleconsultation')
export class TeleconsultationController {
  constructor(private readonly prisma: PrismaService) {}

  @Public()
  @Post('create-room')
  async createRoom(@Body() body: { examRequestId: string; doctorId: string }) {
    if (!body.examRequestId || !body.doctorId) {
      throw new BadRequestException('examRequestId and doctorId are required');
    }



    const existingRoom = await this.prisma.teleconsultation.findFirst({
      where: { requestId: body.examRequestId },
    });
    
    if (existingRoom) {
      return { success: true, data: existingRoom };
    }

    // Gerar sala Jitsi Meet única para a consulta
    const uniqueHash = Math.random().toString(36).substring(2, 10);
    const roomName = `SaudeSeg-Consulta-${body.examRequestId.slice(0, 8)}-${uniqueHash}`;
    const videoSessionId = `https://meet.jit.si/${roomName}`;
    const hostRoomUrl = videoSessionId;

    const teleconsultation = await this.prisma.teleconsultation.create({
      data: {
        requestId: body.examRequestId,
        doctorId: body.doctorId,
        videoSessionId,
        hostRoomUrl,
        startedAt: new Date(),
      },
    });

    // Atualizar status para EM_ATENDIMENTO_MEDICO
    await this.prisma.examRequest.update({
      where: { id: body.examRequestId },
      data: { status: 'EM_ATENDIMENTO_MEDICO' },
    });

    return { success: true, data: teleconsultation };
  }
}
