import { Module } from '@nestjs/common';
import { TeleconsultationController } from './teleconsultation.controller';
import { PrismaService } from '../prisma.service';

@Module({
  controllers: [TeleconsultationController],
  providers: [PrismaService],
})
export class TeleconsultationModule {}
