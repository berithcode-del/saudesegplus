import { CanActivate, ExecutionContext, Injectable, Logger } from '@nestjs/common';
import { WsException } from '@nestjs/websockets';
import { Socket } from 'socket.io';
import * as crypto from 'crypto';

/**
 * Guard de autenticação JWT para WebSockets.
 * Não depende de JwtService via DI — valida o token
 * diretamente com a secret do ambiente, evitando
 * conflitos de injeção de dependência entre módulos.
 */
@Injectable()
export class WsJwtGuard implements CanActivate {
  private readonly logger = new Logger(WsJwtGuard.name);

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const client: Socket = context.switchToWs().getClient<Socket>();

    const token =
      client.handshake.auth?.token ||
      (client.handshake.headers['authorization'] as string)?.split(' ')[1];

    if (!token) {
      this.logger.warn(`[WsJwtGuard] Cliente ${client.id} sem token — conexão recusada`);
      throw new WsException('Unauthorized');
    }

    try {
      const payload = WsJwtGuard.verifyToken(token);
      client.data.user = payload;
      return true;
    } catch {
      this.logger.warn(`[WsJwtGuard] Token inválido do cliente ${client.id}`);
      throw new WsException('Unauthorized');
    }
  }

  /**
   * Verifica o JWT manualmente (HMAC-SHA256 HS256) sem usar JwtService.
   * Isso evita dependências de módulo que causam erros de DI no NestJS.
   */
  private static verifyToken(token: string): Record<string, unknown> {
    const secret = process.env.JWT_SECRET ?? 'saudeseg-dev-secret';
    const parts = token.split('.');

    if (parts.length !== 3) throw new Error('Token malformado');

    const [header, payload, signature] = parts;

    // Recomputa a assinatura
    const expectedSig = crypto
      .createHmac('sha256', secret)
      .update(`${header}.${payload}`)
      .digest('base64url');

    if (expectedSig !== signature) {
      throw new Error('Assinatura inválida');
    }

    // Decodifica o payload
    const decoded = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));

    // Verifica expiração
    if (decoded.exp && decoded.exp < Math.floor(Date.now() / 1000)) {
      throw new Error('Token expirado');
    }

    return decoded as Record<string, unknown>;
  }
}
