import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { MailService } from '../mail/mail.service';
import { FinancialService } from '../financial/financial.service';
import * as puppeteer from 'puppeteer-core';
import * as fs from 'fs';
import * as path from 'path';

@Injectable()
export class AsoService {
  private readonly logger = new Logger(AsoService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly mailService: MailService,
    private readonly financialService: FinancialService,
  ) {}

  async generatePdf(examRequestId: string, doctorId: string, decision: string, restrictionNotes?: string) {
    const request = await this.prisma.examRequest.findUnique({
      where: { id: examRequestId },
      include: {
        patient: true,
        invite: { include: { company: true } },
      },
    });
    if (!request) throw new NotFoundException('Solicitação não encontrada');

    const doctor = await this.prisma.doctor.findUnique({ where: { id: doctorId } });
    if (!doctor) throw new NotFoundException('Médico não encontrado');

    let asoDoc = await this.prisma.asoDocument.findFirst({
      where: { requestId: examRequestId },
      orderBy: { signedAt: 'desc' },
    });

    if (!asoDoc) {
      asoDoc = await this.prisma.asoDocument.create({
        data: {
          requestId: examRequestId,
          doctorId,
          decision,
          restrictionNotes: restrictionNotes ?? '',
          signedAt: new Date(),
          validUntil: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
        },
      });
    }

    const todayPtBr = new Date().toLocaleDateString('pt-BR');

    const data: Record<string, string> = {
      patientName: request.patient.name,
      patientCpf: request.patient.cpf,
      companyName: request.invite?.company?.nomeFantasia ?? request.invite?.company?.name ?? '',
      examPurpose: request.examPurpose ?? '',
      examDate: todayPtBr,
      decision,
      restrictionNotes: restrictionNotes ?? '',
      doctorCrm: `${doctor.crmNumber} ${doctor.crmState}`,
      signatureDate: todayPtBr,
    };

    const templatePath = path.join(__dirname, '..', '..', '..', '..', 'libs', 'pdf-template-aso.html');
    let html = fs.readFileSync(templatePath, 'utf8');

    Object.entries(data).forEach(([key, value]) => {
      html = html.replace(new RegExp(`\\{\\{\\s*${key}\\s*\\}\\}`, 'g'), value);
    });

    html = html.replace(/\{\{#if\s+(\w+)\}\}[\s\S]*?\{\{\/if\}\}/g, (match, varName) => {
      return data[varName] ? match.replace(/\{\{#if\s+\w+\}\}/, '').replace(/\{\{\/if\}\}/, '') : '';
    });

    const pdfDir = path.join(__dirname, '..', '..', '..', '..', 'uploads', 'aso');
    if (!fs.existsSync(pdfDir)) {
      fs.mkdirSync(pdfDir, { recursive: true });
    }

    const pdfPath = path.join(pdfDir, `aso-${asoDoc.id}.pdf`);

    const browser = await puppeteer.launch({
      headless: true,
      executablePath: process.env.CHROME_PATH ?? undefined,
      args: ['--no-sandbox', '--disable-setuid-sandbox'],
    });

    try {
      const page = await browser.newPage();
      await page.setContent(html, { waitUntil: 'load' });
      await page.pdf({ path: pdfPath, format: 'A4', printBackground: true });
    } finally {
      await browser.close();
    }

    const pdfUrl = `/uploads/aso/aso-${asoDoc.id}.pdf`;

    await this.prisma.asoDocument.update({
      where: { id: asoDoc.id },
      data: { pdfUrl, decision, restrictionNotes: restrictionNotes ?? '' },
    });

    await this.prisma.examRequest.update({
      where: { id: examRequestId },
      data: { status: 'CONCLUIDO' },
    });

    try {
      await this.financialService.generateExamTransactions(examRequestId);
      this.logger.log(`Transações financeiras geradas para ASO ${examRequestId}`);
    } catch (err) {
      this.logger.error(`Erro ao gerar transações financeiras para ASO ${examRequestId}`, err);
    }

    this.logger.log(`ASO PDF gerado: ${pdfPath}`);

    const patientUser = await this.prisma.userAccount.findUnique({ where: { id: request.patient.userId } });
    if (patientUser?.email && !patientUser.email.endsWith('@walkin.temp')) {
      try {
        await this.mailService.sendAsoReady(patientUser.email, request.patient.name, pdfUrl);
      } catch (err) {
        console.error(`[Mail] Falha ao enviar ASO para ${patientUser.email}:`, err);
      }
    }

    return { pdfUrl, asoDocumentId: asoDoc.id };
  }
}
