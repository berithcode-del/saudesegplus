import { Controller, Post, Body } from '@nestjs/common';
import { AsoService } from './aso.service';

@Controller('api/aso')
export class AsoController {
  constructor(private readonly asoService: AsoService) {}

  @Post('generate')
  async generatePdf(@Body() body: { examRequestId: string; doctorId: string; decision: string; restrictionNotes?: string }) {
    const result = await this.asoService.generatePdf(
      body.examRequestId,
      body.doctorId,
      body.decision,
      body.restrictionNotes,
    );
    return { success: true, pdfUrl: result.pdfUrl };
  }
}
