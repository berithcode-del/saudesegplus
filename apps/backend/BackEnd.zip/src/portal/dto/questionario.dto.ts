import { IsOptional, IsString } from 'class-validator';

export class QuestionarioDto {
  @IsOptional()
  @IsString()
  queixas?: string;

  @IsOptional()
  @IsString()
  doencasPrevias?: string;

  @IsOptional()
  @IsString()
  medicamentosEmUso?: string;

  @IsOptional()
  @IsString()
  alergiasConhecidas?: string;

  @IsOptional()
  @IsString()
  cirurgiasPrevias?: string;

  @IsOptional()
  @IsString()
  observacoes?: string;
}
