'use client';
import { useState, useEffect } from 'react';

interface ExamFormProps {
  examType: 'pa' | 'audiometria' | 'acuidade_visual';
  onValidChange?: (isValid: boolean) => void;
}

export default function ExamForm({ examType, onValidChange }: ExamFormProps) {
  // Campos por tipo de exame
  const fields = {
    pa: [
      { id: 'pressao_sistolica', label: 'Pressão Sistólica (mmHg)', type: 'number', required: true },
      { id: 'pressao_diastolica', label: 'Pressão Diastólica (mmHg)', type: 'number', required: true },
    ],
    audiometria: [
      { id: 'via_aerea_od', label: 'Via Aérea OD', type: 'text', required: true },
      { id: 'via_aerea_oe', label: 'Via Aérea OE', type: 'text', required: true },
      { id: 'via_ossea_od', label: 'Via Óssea OD', type: 'text', required: false },
      { id: 'via_ossea_oe', label: 'Via Óssea OE', type: 'text', required: false },
    ],
    acuidade_visual: [
      { id: 'od', label: 'Acuidade Visual OD', type: 'text', required: true },
      { id: 'oe', label: 'Acuidade Visual OE', type: 'text', required: true },
    ],
  };

  const [values, setValues] = useState<Record<string, string>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Validar campos obrigatórios
  const validate = () => {
    const newErrors: Record<string, string> = {};
    let isValid = true;

    fields[examType].forEach((field) => {
      if (field.required && !values[field.id]) {
        newErrors[field.id] = 'Campo obrigatório';
        isValid = false;
      }
    });

    setErrors(newErrors);
    return isValid;
  };

  // Monitorar mudanças e validar
  useEffect(() => {
    const isValid = validate();
    onValidChange?.(isValid);
  }, [values]);

  const handleChange = (fieldId: string, value: string) => {
    setValues((prev) => ({ ...prev, [fieldId]: value }));
  };

  return (
    <div className="form-grid">
      {fields[examType].map((field) => (
        <div className="form-group" key={field.id}>
          <label className="form-label" htmlFor={field.id}>
            {field.label} {field.required && <span style={{ color: '#e53e3e' }}>*</span>}
          </label>
          <input
            id={field.id}
            type={field.type}
            className="form-input"
            value={values[field.id] || ''}
            onChange={(e) => handleChange(field.id, e.target.value)}
          />
          {errors[field.id] && <p style={{ color: '#e53e3e', fontSize: '12px', marginTop: '4px' }}>{errors[field.id]}</p>}
        </div>
      ))}
    </div>
  );
}