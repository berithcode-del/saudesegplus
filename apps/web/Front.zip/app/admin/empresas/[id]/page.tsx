'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { apiAdminListCompanies, apiAdminUpdateCompanyStatus } from '../../../../app/lib/api';

interface Company {
  id: string;
  razaoSocial?: string;
  nomeFantasia?: string;
  cnpj: string;
  status: string;
  address?: string;
  city?: string;
  state?: string;
}

export default function AdminEmpresaDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const [company, setCompany] = useState<Company | null>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    apiAdminListCompanies({ id: params.id })
      .then(r => {
        const data = Array.isArray(r.data) ? r.data[0] : r.data;
        setCompany(data ?? null);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [params.id]);

  const handleStatusChange = async (status: string) => {
    const labels: Record<string, string> = {
      LIBERADA: 'Aprovar empresa',
      DOCUMENTACAO_VENCIDA: 'Bloquear empresa',
    };
    if (!window.confirm(`${labels[status] ?? status}?`)) return;
    setActionLoading(true);
    try {
      await apiAdminUpdateCompanyStatus(params.id, status);
      setCompany(prev => prev ? { ...prev, status } : prev);
    } catch { alert('Erro ao alterar status.'); }
    finally { setActionLoading(false); }
  };

  if (loading) return <div className="page-center"><p style={{ color: 'var(--text-muted)' }}>Carregando...</p></div>;
  if (!company) return <div className="page-center"><p style={{ color: '#dc2626' }}>Empresa não encontrada</p></div>;

  return (
    <>
      <div className="page-header">
        <h2>{company.razaoSocial ?? company.nomeFantasia ?? 'Empresa'}</h2>
        <p>CNPJ: {company.cnpj}</p>
      </div>
      <div className="card" style={{ marginBottom: '20px' }}>
        <div className="form-grid">
          <div><strong>Razão Social:</strong> {company.razaoSocial ?? '—'}</div>
          <div><strong>Nome Fantasia:</strong> {company.nomeFantasia ?? '—'}</div>
          <div><strong>CNPJ:</strong> {company.cnpj}</div>
          <div><strong>Endereço:</strong> {[company.address, company.city, company.state].filter(Boolean).join(', ') || '—'}</div>
          <div><strong>Status:</strong> {company.status}</div>
        </div>
      </div>
      <div className="card">
        <h3 style={{ marginBottom: '16px' }}>Ações</h3>
        <div style={{ display: 'flex', gap: '12px' }}>
          <button className="btn btn-success" onClick={() => handleStatusChange('LIBERADA')} disabled={actionLoading || company.status === 'LIBERADA'}>
            Aprovar Empresa
          </button>
          <button className="btn btn-danger" onClick={() => handleStatusChange('DOCUMENTACAO_VENCIDA')} disabled={actionLoading}>
            Bloquear
          </button>
          <button className="btn btn-ghost" onClick={() => router.push('/admin/empresas')}>Voltar</button>
        </div>
      </div>
    </>
  );
}
