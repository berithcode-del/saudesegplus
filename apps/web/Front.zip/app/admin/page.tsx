'use client';
import { useEffect, useState } from 'react';
import { BuildingOffice2Icon, UserGroupIcon, DocumentTextIcon, CheckBadgeIcon } from '@heroicons/react/24/outline';
import { apiAdminStats } from '../../app/lib/api';

interface AdminStats {
  totalCompanies: number;
  totalPatients: number;
  totalSolicitacoes: number;
  totalAsoEmitidos: number;
}

export default function AdminDashboardPage() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiAdminStats()
      .then(r => setStats(r.data ?? r))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const cards = [
    { label: 'Empresas', value: stats?.totalCompanies ?? 0, icon: BuildingOffice2Icon, color: '#3b6ff5' },
    { label: 'Pacientes', value: stats?.totalPatients ?? 0, icon: UserGroupIcon, color: '#7c3aed' },
    { label: 'Solicitações', value: stats?.totalSolicitacoes ?? 0, icon: DocumentTextIcon, color: '#d97706' },
    { label: 'ASOs Emitidos', value: stats?.totalAsoEmitidos ?? 0, icon: CheckBadgeIcon, color: '#16a34a' },
  ];

  if (loading) return <div className="page-center"><p style={{ color: 'var(--text-muted)' }}>Carregando...</p></div>;

  return (
    <>
      <div className="page-header">
        <h2>Dashboard</h2>
        <p>Métricas globais da plataforma</p>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '20px' }}>
        {cards.map(card => (
          <div key={card.label} className="card" style={{ textAlign: 'center', padding: '28px 20px' }}>
            <card.icon className="icon" style={{ width: '40px', height: '40px', color: card.color, marginBottom: '12px' }} />
            <div style={{ fontSize: '28px', fontWeight: 800, color: '#1e1b4b' }}>{card.value}</div>
            <div style={{ fontSize: '14px', color: '#6b7280', marginTop: '4px' }}>{card.label}</div>
          </div>
        ))}
      </div>
    </>
  );
}
