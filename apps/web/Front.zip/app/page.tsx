'use client';
import { useRouter } from 'next/navigation';
import { ShieldCheckIcon, HeartIcon, BuildingOffice2Icon, BuildingStorefrontIcon, UserGroupIcon } from '@heroicons/react/24/outline';

const ROLES = [
  { role: 'DOCTOR', label: 'Médico', icon: HeartIcon, href: '/medico/fila' },
  { role: 'OPERATOR', label: 'Operador', icon: ShieldCheckIcon, href: '/consultorio' },
  { role: 'COMPANY_ADMIN', label: 'Empresa', icon: BuildingOffice2Icon, href: '/empresa' },
  { role: 'ADMIN', label: 'Administrador', icon: UserGroupIcon, href: '/admin' },
];

export default function LoginPage() {
  const router = useRouter();

  return (
    <div className="login-page">
      <div className="login-card" style={{ maxWidth: '500px', margin: '80px auto', padding: '40px' }}>
        <div style={{ textAlign: 'center', marginBottom: '32px' }}>
          <div style={{
            width: '56px', height: '56px', borderRadius: '50%',
            background: 'rgba(79,70,229,0.12)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 16px',
          }}>
            <BuildingStorefrontIcon style={{ width: '28px', height: '28px', color: '#4f46e5' }} />
          </div>
          <h1 style={{ fontSize: '24px', fontWeight: 800, color: '#1e1b4b' }}>SaúdeSeg+</h1>
          <p style={{ color: '#6b7280', fontSize: '14px' }}>Plataforma de Saúde Ocupacional</p>
        </div>

        <p style={{ textAlign: 'center', color: '#6b7280', fontSize: '14px', marginBottom: '24px' }}>
          Selecione seu perfil para acessar o sistema
        </p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {ROLES.map(({ role, label, icon: Icon, href }) => (
            <button
              key={role}
              className="btn btn-secondary"
              style={{
                display: 'flex', alignItems: 'center', gap: '12px',
                padding: '16px 20px', justifyContent: 'flex-start',
                fontSize: '15px', fontWeight: 600,
              }}
              onClick={() => router.push(href)}
            >
              <Icon className="icon" style={{ width: '24px', height: '24px', color: '#4f46e5' }} />
              {label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
