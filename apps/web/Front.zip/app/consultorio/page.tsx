'use client';
import { useState, useEffect } from 'react';
import GreetingClinic from '../../components/consultorio/GreetingClinic';
import ClinicStats from '../../components/consultorio/ClinicStats';
import PatientQueueTable from '../../components/consultorio/PatientQueueTable';
import QuickActionsClinic from '../../components/consultorio/QuickActionsClinic';
import DailyFlowChart from '../../components/consultorio/DailyFlowChart';
import ScheduleCalendar from '../../components/dashboard/ScheduleCalendar';
import { apiGetEvents } from '../../lib/api';

const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL ?? 'http://localhost:3001';

interface Solicitacao {
  id: string;
  examPurpose: string;
  status: string;
  createdAt: string;
  patient: { name: string; cpf: string };
  clinic?: { name: string; city: string; state: string } | null;
}

export default function ConsultorioDashboard() {
  const [solicitacoes, setSolicitacoes] = useState<Solicitacao[]>([]);
  const [loading, setLoading] = useState(true);
  const [clinicName, setClinicName] = useState<string>('Clínica');
  const [clinicId, setClinicId] = useState<string>('');
  const [events, setEvents] = useState<any[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Buscar clínicas para obter o ID
        const clinicsRes = await fetch(`${BACKEND_URL}/api/clinics`);
        const clinicsResult = await clinicsRes.json();
        const clinics = clinicsResult.data ?? [];
        const currentClinic = clinics[0];
        if (currentClinic) {
          setClinicId(currentClinic.id);
          setClinicName(currentClinic.name);
        }

        // Buscar solicitações e eventos em paralelo
        const [solRes, eventsData] = await Promise.all([
          fetch(`${BACKEND_URL}/api/solicitacoes`),
          currentClinic ? apiGetEvents('clinic', currentClinic.id) : Promise.resolve([]),
        ]);
        const result = await solRes.json();
        const data = Array.isArray(result.data) ? result.data : [];
        setSolicitacoes(data);
        if (eventsData) setEvents(eventsData);

        // Fallback para nome da clínica a partir das solicitações
        if (!currentClinic) {
          const firstWithClinic = data.find((d: any) => d.clinic?.name);
          if (firstWithClinic) setClinicName(firstWithClinic.clinic.name);
        }
      } catch {
        console.error('Erro ao carregar solicitações');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) {
    return <div style={{ padding: '32px', textAlign: 'center', color: '#6b7280' }}>Carregando painel...</div>;
  }

  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: 'minmax(0, 8fr) minmax(0, 4fr)',
        gap: '24px',
        alignItems: 'start',
        overflow: 'visible',
      }}
    >
      {/* ── Coluna Esquerda (70%) ────────────── */}
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '24px',
          overflow: 'visible',
          paddingTop: '60px',
        }}
      >
        <GreetingClinic name={clinicName} />
        <ClinicStats solicitacoes={solicitacoes} />
        <PatientQueueTable solicitacoes={solicitacoes} />
      </div>

      {/* ── Coluna Direita (30%) ─────────────── */}
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '24px',
          paddingTop: '60px',
        }}
      >
        <QuickActionsClinic />
        <DailyFlowChart solicitacoes={solicitacoes} />
        <ScheduleCalendar
          ownerType="clinic"
          ownerId={clinicId}
          events={events}
          onEventCreated={() => {
            if (clinicId) apiGetEvents('clinic', clinicId).then(res => setEvents(res));
          }}
        />
      </div>
    </div>
  );
}
