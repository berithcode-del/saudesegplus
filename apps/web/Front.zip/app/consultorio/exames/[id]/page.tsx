'use client';
import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { PaperAirplaneIcon } from '@heroicons/react/24/outline';
import ExamForm from '@/components/ExamForm';

const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL ?? 'http://localhost:3001';

interface Solicitacao {
  id: string;
  examPurpose: string;
  status: string;
  patient: { name: string; cpf: string; functionCboCode: string };
  clinic?: { name: string } | null;
}

export default function ExamPage() {
  const params = useParams();
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [solicitacao, setSolicitacao] = useState<Solicitacao | null>(null);
  const [error, setError] = useState('');
  const [examType, setExamType] = useState<'pa' | 'audiometria' | 'acuidade_visual'>('pa');
  const [isFormValid, setIsFormValid] = useState(false);
  const [examsSaved, setExamsSaved] = useState(false);

  useEffect(() => {
    const fetchSolicitacao = async () => {
      try {
        const res = await fetch(`${BACKEND_URL}/api/solicitacoes/${params.id}`);
        const result = await res.json();
        if (result.data) {
          setSolicitacao(result.data);
        } else {
          setError('Solicitação não encontrada');
        }
      } catch {
        setError('Erro ao carregar dados da solicitação');
      } finally {
        setLoading(false);
      }
    };
    fetchSolicitacao();
  }, [params.id]);

  const handleSaveExams = async () => {
    setSaving(true);
    try {
      const res = await fetch(`${BACKEND_URL}/api/exams`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          examRequestId: params.id,
          examType,
          valueJson: {},
        }),
      });
      const result = await res.json();
      if (result.success) {
        setExamsSaved(true);
      } else {
        setError('Erro ao salvar exames');
      }
    } catch {
      setError('Erro ao conectar com o servidor');
    } finally {
      setSaving(false);
    }
  };

  const handleSendToQueue = async () => {
    setSaving(true);
    try {
      const res = await fetch(`${BACKEND_URL}/api/exams/${params.id}/send-to-queue`, {
        method: 'POST',
      });
      const result = await res.json();
      if (result.success) {
        router.push('/consultorio');
      } else {
        setError('Erro ao enviar para fila médica');
      }
    } catch {
      setError('Erro ao conectar com o servidor');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="page-center">
        <p style={{ color: 'var(--text-muted)' }}>Carregando...</p>
      </div>
    );
  }

  if (error && !solicitacao) {
    return (
      <div className="page-center">
        <p style={{ color: '#dc2626' }}>{error}</p>
      </div>
    );
  }

  return (
    <div>
      <div className="page-header">
        <h2>Exames de {solicitacao?.patient.name}</h2>
        <p>Tipo: <strong>{solicitacao?.examPurpose}</strong> | CPF: {solicitacao?.patient.cpf}</p>
      </div>

      {error && (
        <div className="login-hint" style={{ background: 'rgba(239,68,68,0.08)', borderColor: 'rgba(239,68,68,0.25)', color: '#dc2626', marginBottom: '16px' }}>
          {error}
        </div>
      )}

      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <h3>Registrar Exames</h3>
          <select
            className="form-select"
            value={examType}
            onChange={(e) => setExamType(e.target.value as 'pa' | 'audiometria' | 'acuidade_visual')}
            style={{ width: 'auto' }}
          >
            <option value="pa">Pressão Arterial</option>
            <option value="audiometria">Audiometria</option>
            <option value="acuidade_visual">Acuidade Visual</option>
          </select>
        </div>

        <ExamForm examType={examType} onValidChange={setIsFormValid} />

        <div style={{ display: 'flex', gap: '12px', marginTop: '16px' }}>
          <button
            className="btn btn-primary"
            disabled={!isFormValid || saving || examsSaved}
            onClick={handleSaveExams}
          >
            {saving ? 'Salvando...' : 'Salvar Exames'}
          </button>
          <button
            className="btn btn-success"
            disabled={!examsSaved || saving}
            onClick={handleSendToQueue}
          >
            {saving ? 'Enviando...' : (<><PaperAirplaneIcon className="icon" /> Enviar para Fila Médica</>)}
          </button>
        </div>
      </div>
    </div>
  );
}
