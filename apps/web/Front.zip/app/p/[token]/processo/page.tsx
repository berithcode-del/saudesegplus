'use client';
import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import {
  CheckCircleIcon,
  ArrowRightIcon,
  ChevronDownIcon,
  ChevronUpIcon,
  ClockIcon,
  MapPinIcon,
  DocumentTextIcon,
  VideoCameraIcon,
  ClipboardDocumentCheckIcon,
  PencilSquareIcon,
  ArrowUpTrayIcon,
} from '@heroicons/react/24/outline';

const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL ?? 'http://localhost:3001';

const etapas = [
  { chave: 'CADASTRO', label: 'Cadastro' },
  { chave: 'DOCUMENTOS', label: 'Documentos' },
  { chave: 'QUESTIONARIO', label: 'Questionário' },
  { chave: 'EXAMES', label: 'Exames' },
  { chave: 'MEDICO', label: 'Médico' },
  { chave: 'ASO', label: 'ASO' },
];

interface ProcessoData {
  id?: string;
  status?: string;
  etapaAtual?: string;
  paciente?: {
    nome?: string;
    cpf?: string;
  };
  empresa?: {
    nome?: string;
  };
  clinica?: {
    nome?: string;
    endereco?: string;
    latitude?: number;
    longitude?: number;
  };
  proximaAcao?: {
    tipo: string;
    titulo?: string;
    descricao?: string;
  };
  timeline?: Array<{
    tipo: string;
    descricao: string;
    ocorridoEm: string;
  }>;
  linkSala?: string | null;
}

const acaoConfig: Record<string, { label: string; Icon: typeof ArrowRightIcon }> = {
  CONFIRMAR_DADOS: { label: 'Confirmar dados', Icon: ClipboardDocumentCheckIcon },
  ENVIAR_DOCUMENTOS: { label: 'Enviar documentos', Icon: ArrowUpTrayIcon },
  RESPONDER_QUESTIONARIO: { label: 'Responder questionário', Icon: PencilSquareIcon },
  ENTRAR_TELECONSULTA: { label: 'Entrar na teleconsulta', Icon: VideoCameraIcon },
  BAIXAR_ASO: { label: 'Baixar ASO', Icon: DocumentTextIcon },
};

function getEtapaAtualIndex(etapa?: string): number {
  const idx = etapas.findIndex(e => e.chave === etapa);
  return idx >= 0 ? idx : 0;
}

export default function ProcessoPage({ params }: { params: { token: string } }) {
  const router = useRouter();
  const [data, setData] = useState<ProcessoData | null>(null);
  const [loading, setLoading] = useState(true);
  const [timelineOpen, setTimelineOpen] = useState(false);
  const [showWelcome, setShowWelcome] = useState(false);

  useEffect(() => {
    const shown = sessionStorage.getItem('primeiroAcessoConcluido');
    if (!shown) setShowWelcome(true);
  }, []);

  const dismissWelcome = () => {
    setShowWelcome(false);
    sessionStorage.setItem('primeiroAcessoConcluido', '1');
  };

  const fetchProcesso = useCallback(async () => {
    const portalToken = sessionStorage.getItem('portalToken');
    if (!portalToken) {
      router.replace(`/p/${params.token}`);
      return;
    }
    try {
      const res = await fetch(`${BACKEND_URL}/api/portal/processo`, {
        headers: { Authorization: `Bearer ${portalToken}` },
      });
      if (res.status === 401) {
        sessionStorage.removeItem('portalToken');
        router.replace(`/p/${params.token}`);
        return;
      }
      const json = await res.json();
      if (json.data) setData(json.data);
    } catch {
      // polling will retry
    } finally {
      setLoading(false);
    }
  }, [params.token, router]);

  useEffect(() => {
    fetchProcesso();
    const interval = setInterval(fetchProcesso, 30000);
    return () => clearInterval(interval);
  }, [fetchProcesso]);

  const handleCta = () => {
    if (!data?.proximaAcao) return;
    const tipo = data.proximaAcao.tipo;
    const map: Record<string, string> = {
      CONFIRMAR_DADOS: `/p/${params.token}/confirmar`,
      ENVIAR_DOCUMENTOS: `/p/${params.token}/documentos`,
      RESPONDER_QUESTIONARIO: `/p/${params.token}/questionario`,
      ENTRAR_TELECONSULTA: `/p/${params.token}/teleconsulta`,
      BAIXAR_ASO: `/p/${params.token}/aso`,
    };
    const path = map[tipo];
    if (path) router.push(path);
  };

  if (showWelcome) {
    return (
      <div style={{
        background: 'white',
        borderRadius: '20px',
        padding: '32px 24px',
        boxShadow: '0 2px 12px rgba(31,38,135,0.08)',
        border: '1px solid #e5e7eb',
        textAlign: 'center',
      }}>
        <h1 style={{ fontSize: '22px', fontWeight: 700, color: '#1e1b4b', marginBottom: '8px' }}>
          Bem-vindo!
        </h1>
        <p style={{ fontSize: '14px', color: '#6b7280', marginBottom: '24px' }}>
          Seu processo seletivo de saúde ocupacional está pronto.
        </p>
        <div style={{
          padding: '16px', borderRadius: '12px',
          background: 'rgba(79,70,229,0.05)',
          border: '1px solid rgba(79,70,229,0.12)',
          marginBottom: '24px', textAlign: 'left',
        }}>
          <div style={{ fontSize: '13px', marginBottom: '8px' }}>
            <span style={{ color: '#6b7280' }}>Paciente: </span>
            <strong style={{ color: '#1e1b4b' }}>{sessionStorage.getItem('patientName')}</strong>
          </div>
          <div style={{ fontSize: '13px', marginBottom: '8px' }}>
            <span style={{ color: '#6b7280' }}>Empresa: </span>
            <strong style={{ color: '#1e1b4b' }}>{sessionStorage.getItem('companyName')}</strong>
          </div>
          <div style={{ fontSize: '13px' }}>
            <span style={{ color: '#6b7280' }}>Tipo de Exame: </span>
            <strong style={{ color: '#1e1b4b' }}>{sessionStorage.getItem('examPurpose')}</strong>
          </div>
        </div>
        <button
          className="btn btn-primary"
          style={{ width: '100%', justifyContent: 'center' }}
          onClick={dismissWelcome}
        >
          Iniciar Processo
        </button>
      </div>
    );
  }

  const etapaIndex = getEtapaAtualIndex(data?.etapaAtual);
  const acao = data?.proximaAcao;
  const config = acao ? acaoConfig[acao.tipo] : null;
  const isCtaClickable = !!config && !['AGUARDAR_RESULTADOS', 'AGUARDAR_MEDICO'].includes(acao?.tipo ?? '');

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '60px 0', color: '#9ca3af' }}>
        Carregando...
      </div>
    );
  }

  return (
    <div>
      {/* Barra de Progresso */}
      <div style={{
        background: 'white',
        borderRadius: '16px',
        padding: '20px 16px',
        boxShadow: '0 2px 12px rgba(31,38,135,0.08)',
        border: '1px solid #e5e7eb',
        marginBottom: '20px',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', position: 'relative' }}>
          <div style={{
            position: 'absolute', top: '12px', left: '8%', right: '8%',
            height: '3px', background: '#e5e7eb', zIndex: 0,
          }} />
          <div style={{
            position: 'absolute', top: '12px', left: '8%',
            height: '3px', background: '#7c3aed', zIndex: 0,
            width: `${(etapaIndex / (etapas.length - 1)) * 84}%`,
            transition: 'width 0.4s ease',
          }} />
          {etapas.map((e, i) => {
            const concluida = i < etapaIndex;
            const atual = i === etapaIndex;
            return (
              <div key={e.chave} style={{
                display: 'flex', flexDirection: 'column', alignItems: 'center',
                gap: '6px', zIndex: 1, width: '14%',
              }}>
                <div style={{
                  width: '24px', height: '24px', borderRadius: '50%',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: '11px', fontWeight: 700, color: 'white',
                  background: concluida ? '#7c3aed' : atual ? '#3b6ff5' : '#d1d5db',
                  boxShadow: atual ? '0 0 0 4px rgba(59,111,245,0.2)' : 'none',
                  animation: atual ? 'pulse-dot 1.5s infinite' : 'none',
                }}>
                  {concluida ? '✓' : i + 1}
                </div>
                <span style={{
                  fontSize: '9px', fontWeight: 600,
                  color: concluida ? '#7c3aed' : atual ? '#3b6ff5' : '#9ca3af',
                  textAlign: 'center', lineHeight: 1.2,
                }}>
                  {e.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Card de Próxima Ação */}
      <div style={{
        background: 'white',
        borderRadius: '20px',
        padding: '28px 24px',
        boxShadow: '0 2px 12px rgba(31,38,135,0.08)',
        border: '1px solid #e5e7eb',
        textAlign: 'center',
        marginBottom: '20px',
      }}>
        {config ? (
          <config.Icon style={{ width: '48px', height: '48px', color: '#4f46e5', marginBottom: '16px' }} />
        ) : (
          <ClockIcon style={{ width: '48px', height: '48px', color: '#9ca3af', marginBottom: '16px' }} />
        )}
        <h2 style={{ fontSize: '18px', fontWeight: 700, color: '#1e1b4b', marginBottom: '6px' }}>
          {acao?.titulo ?? 'Próxima ação'}
        </h2>
        <p style={{ fontSize: '14px', color: '#6b7280', marginBottom: '16px', lineHeight: 1.5 }}>
          {acao?.descricao ?? 'Aguardando atualização do processo.'}
        </p>

        {data?.clinica && (
          <div style={{
            padding: '12px 14px', borderRadius: '12px',
            background: 'rgba(79,70,229,0.05)',
            border: '1px solid rgba(79,70,229,0.12)',
            marginBottom: '16px', textAlign: 'left',
          }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: '8px' }}>
              <MapPinIcon style={{ width: '16px', height: '16px', color: '#4f46e5', flexShrink: 0, marginTop: '2px' }} />
              <div>
                <div style={{ fontSize: '13px', fontWeight: 600, color: '#1e1b4b' }}>{data.clinica.nome}</div>
                {data.clinica.endereco && (
                  <div style={{ fontSize: '12px', color: '#6b7280' }}>{data.clinica.endereco}</div>
                )}
                {data.clinica.latitude && data.clinica.longitude && (
                  <a
                    href={`https://www.google.com/maps/dir/?api=1&destination=${data.clinica.latitude},${data.clinica.longitude}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{ fontSize: '12px', color: '#3b6ff5', textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: '4px', marginTop: '4px' }}
                  >
                    <MapPinIcon style={{ width: '12px', height: '12px' }} />
                    Abrir no Google Maps
                  </a>
                )}
              </div>
            </div>
          </div>
        )}

        {config && isCtaClickable ? (
          <button
            className="btn btn-primary"
            style={{ width: '100%', justifyContent: 'center' }}
            onClick={handleCta}
          >
            {config.label}
            <ArrowRightIcon style={{ width: '16px', height: '16px' }} />
          </button>
        ) : acao && ['AGUARDAR_RESULTADOS', 'AGUARDAR_MEDICO'].includes(acao.tipo) ? (
          <div style={{
            padding: '12px 14px', borderRadius: '12px',
            background: 'rgba(245,158,11,0.08)',
            border: '1px solid rgba(245,158,11,0.2)',
            fontSize: '13px', color: '#d97706',
          }}>
            <ClockIcon style={{ width: '16px', height: '16px', verticalAlign: 'middle', marginRight: '6px' }} />
            Acompanhando...
          </div>
        ) : acao?.tipo === 'COMPARECER_CLINICA' && data?.clinica ? (
          <div style={{
            padding: '12px 14px', borderRadius: '12px',
            background: 'rgba(79,70,229,0.08)',
            border: '1px solid rgba(79,70,229,0.2)',
            fontSize: '13px', color: '#4f46e5',
          }}>
            <MapPinIcon style={{ width: '16px', height: '16px', verticalAlign: 'middle', marginRight: '6px' }} />
            {data.clinica.endereco && (
              <a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(data.clinica.endereco)}`} target="_blank" rel="noopener noreferrer" style={{color: '#3b6ff5', textDecoration: 'none'}}>
                Abrir no Google Maps
              </a>
            )}
          </div>
        ) : null}
      </div>

      {/* Timeline */}
      {data?.timeline && data.timeline.length > 0 && (
        <div style={{
          background: 'white',
          borderRadius: '16px',
          border: '1px solid #e5e7eb',
          overflow: 'hidden',
        }}>
          <button
            onClick={() => setTimelineOpen(!timelineOpen)}
            style={{
              width: '100%', padding: '16px 20px', display: 'flex',
              justifyContent: 'space-between', alignItems: 'center',
              background: 'transparent', border: 'none', cursor: 'pointer',
              fontSize: '14px', fontWeight: 600, color: '#1e1b4b',
              fontFamily: 'inherit',
            }}
          >
            <span>Ver histórico</span>
            {timelineOpen ? (
              <ChevronUpIcon style={{ width: '18px', height: '18px', color: '#6b7280' }} />
            ) : (
              <ChevronDownIcon style={{ width: '18px', height: '18px', color: '#6b7280' }} />
            )}
          </button>
          {timelineOpen && (
            <div style={{ padding: '0 20px 20px' }}>
              <div style={{ position: 'relative' }}>
                <div style={{
                  position: 'absolute', left: '8px', top: '4px', bottom: '4px',
                  width: '2px', background: '#e5e7eb',
                }} />
                {data.timeline.map((evento, i) => (
                  <div key={i} style={{ display: 'flex', gap: '14px', paddingBottom: '16px', position: 'relative' }}>
                    <div style={{
                      width: '18px', height: '18px', borderRadius: '50%',
                      background: '#7c3aed', flexShrink: 0, zIndex: 1,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}>
                      <CheckCircleIcon style={{ width: '10px', height: '10px', color: 'white' }} />
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: '13px', fontWeight: 600, color: '#1e1b4b', marginBottom: '2px' }}>
                        {evento.descricao}
                      </div>
                      <div style={{ fontSize: '12px', color: '#9ca3af' }}>
                        {new Date(evento.ocorridoEm).toLocaleString('pt-BR')}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
