'use client';
import { useEffect, useState } from 'react';
import { ArrowPathIcon, CheckCircleIcon } from '@heroicons/react/24/outline';
import { apiListMedicos } from '../../lib/api';

interface Medico {
  id: string;
  name: string;
  crmNumber: string;
  crmState: string;
  city?: string;
  state?: string;
  specialties?: string;
}

export default function MedicoConfiguracaoPage() {
  const [medicos, setMedicos] = useState<Medico[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState('');

  useEffect(() => {
    const saved = typeof window !== 'undefined' ? window.localStorage.getItem('doctorId') ?? '' : '';
    setSelectedId(saved);
    fetchMedicos();
  }, []);

  const fetchMedicos = async () => {
    setLoading(true);
    try {
      const r = await apiListMedicos();
      setMedicos(Array.isArray(r.data) ? r.data : []);
    } catch {
      setMedicos([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSelect = (id: string) => {
    setSelectedId(id);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('doctorId', id);
    }
  };

  return (
    <>
      <div className="page-header">
        <h2>Configuração do Médico</h2>
        <p>Selecione o médico ativo para acessar as funcionalidades do painel</p>
      </div>

      <div className="card">
        <div style={{ display: 'flex', gap: '12px', alignItems: 'center', marginBottom: '20px' }}>
          <h3 style={{ fontSize: '16px', fontWeight: 600, flex: 1 }}>Médicos Disponíveis</h3>
          <button className="btn btn-ghost" onClick={fetchMedicos}>
            <ArrowPathIcon className="icon icon-sm" /> Recarregar
          </button>
        </div>

        {loading ? (
          <p style={{ color: 'var(--text-muted)', textAlign: 'center', padding: '40px' }}>Carregando...</p>
        ) : medicos.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '40px' }}>
            <p style={{ color: 'var(--text-secondary)' }}>Nenhum médico cadastrado.</p>
            <p style={{ color: 'var(--text-muted)', fontSize: '14px', marginTop: '8px' }}>
              Solicite ao administrador que cadastre médicos no sistema.
            </p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {medicos.map((m) => {
              const isSelected = m.id === selectedId;
              return (
                <button
                  key={m.id}
                  onClick={() => handleSelect(m.id)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    padding: '14px 16px',
                    border: `2px solid ${isSelected ? 'var(--accent-primary)' : 'var(--border-light)'}`,
                    borderRadius: '10px',
                    background: isSelected ? 'rgba(79,70,229,0.05)' : 'var(--card-bg)',
                    cursor: 'pointer',
                    textAlign: 'left',
                    width: '100%',
                    transition: 'all 0.15s',
                  }}
                >
                  <div style={{
                    width: '20px', height: '20px', borderRadius: '50%',
                    border: `2px solid ${isSelected ? 'var(--accent-primary)' : 'var(--border-color)'}`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    flexShrink: 0,
                  }}>
                    {isSelected && <CheckCircleIcon style={{ width: '16px', height: '16px', color: 'var(--accent-primary)' }} />}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{m.name}</div>
                    <div style={{ fontSize: '13px', color: 'var(--text-muted)' }}>
                      CRM {m.crmNumber}/{m.crmState}
                      {m.specialties ? ` — ${m.specialties}` : ''}
                      {m.city ? ` — ${m.city}` : ''}
                    </div>
                  </div>
                  {isSelected && (
                    <span style={{
                      fontSize: '12px', fontWeight: 600, color: 'var(--accent-primary)',
                      background: 'rgba(79,70,229,0.1)', padding: '4px 10px', borderRadius: '6px',
                    }}>
                      Ativo
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        )}
      </div>

      {selectedId && (
        <div className="card" style={{ marginTop: '16px' }}>
          <div style={{
            display: 'flex', alignItems: 'center', gap: '8px',
            color: '#16a34a', fontWeight: 600, fontSize: '14px',
          }}>
            <CheckCircleIcon className="icon" />
            Médico configurado com sucesso. Acesse as páginas do painel médico.
          </div>
        </div>
      )}
    </>
  );
}
