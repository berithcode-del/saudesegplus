'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import {
  VideoCameraIcon,
  PhoneIcon,
  UserCircleIcon,
  MicrophoneIcon,
  CameraIcon,
  PhoneXMarkIcon,
  MapPinIcon,
  BeakerIcon,
  ClipboardDocumentListIcon,
  PencilSquareIcon,
  ExclamationTriangleIcon,
  CheckCircleIcon,
  XCircleIcon,
  ClockIcon,
  LinkIcon,
  DocumentTextIcon,
} from '@heroicons/react/24/outline';
import { apiGetSolicitacao, apiUpdateSolicitacao, apiCreateVideoRoom, apiFetch } from '../../../lib/api';

type Decision = 'APTO' | 'APTO_COM_RESTRICAO' | 'INAPTO' | '';

interface SolicitacaoData {
  id: string;
  patient: {
    id: string;
    name: string;
    cpf: string;
    birthDate?: string;
    phone?: string;
    functionCboCode?: string;
    anamneses?: Array<{
      queixas?: string;
      historicoOcupacional?: string;
      historicoMedico?: string;
      medicamentos?: string;
      habitos?: string;
    }>;
  };
  examPurpose: string;
  status: string;
  clinic?: { name: string; city?: string; state?: string } | null;
  results?: Array<{
    id: string;
    type?: { name: string };
    valueJson: string;
  }>;
  asoDocuments?: Array<{
    id: string;
    decision: string;
    restrictionNotes?: string;
    validUntil: string;
    pdfUrl?: string;
    createdAt: string;
  }>;
  invite?: { company?: { nomeFantasia?: string; name?: string } } | null;
  teleconsultations?: Array<{
    id: string;
    startedAt: string;
    hostRoomUrl?: string;
  }>;
  createdAt: string;
}

export default function ConsultaPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const [solicitacao, setSolicitacao] = useState<SolicitacaoData | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'exames' | 'anamnese' | 'notas'>('exames');
  const [decision, setDecision] = useState<Decision>('');
  const [notes, setNotes] = useState('');
  const [restriction, setRestriction] = useState('');
  const [signing, setSigning] = useState(false);
  const [signatureUrl, setSignatureUrl] = useState('');
  const [pdfUrl, setPdfUrl] = useState('');
  const [doctorId, setDoctorId] = useState('');
  const [videoRoomUrl, setVideoRoomUrl] = useState<string | null>(null);
  const [creatingRoom, setCreatingRoom] = useState(false);

  useEffect(() => {
    const saved = typeof window !== 'undefined' ? window.localStorage.getItem('doctorId') ?? '' : '';
    setDoctorId(saved);
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const result = await apiGetSolicitacao(params.id);
        if (result.data) {
          setSolicitacao(result.data);
          if (result.data.teleconsultations && result.data.teleconsultations.length > 0) {
            setVideoRoomUrl(result.data.teleconsultations[0].hostRoomUrl ?? null);
          }
        }
      } catch (err) {
        console.error('Erro ao carregar solicitação:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [params.id]);

  const parsedExams = solicitacao?.results?.map((r) => {
    let values: Record<string, string> = {};
    try { values = JSON.parse(r.valueJson); } catch {}
    return { ...r, parsedValues: values };
  });

  function getExamStatus(typeName: string, key: string, value: string): 'normal' | 'attention' | 'critical' | null {
    const num = parseFloat(value);
    if (isNaN(num)) return null;
    if (typeName === 'pa') {
      if (key === 'pressao_sistolica') {
        if (num > 180) return 'critical';
        if (num > 140) return 'attention';
        if (num < 90) return 'attention';
      }
      if (key === 'pressao_diastolica') {
        if (num > 120) return 'critical';
        if (num > 90) return 'attention';
        if (num < 60) return 'attention';
      }
    }
    if (typeName === 'glicemia') {
      if (num > 300) return 'critical';
      if (num > 126) return 'attention';
      if (num < 70) return 'attention';
    }
    return null;
  }

  const anamnese = solicitacao?.patient?.anamneses?.[0];

  const handleCreateRoom = async () => {
    if (!doctorId) return;
    setCreatingRoom(true);
    try {
      const result = await apiCreateVideoRoom(params.id, doctorId);
      setVideoRoomUrl(result.data?.hostRoomUrl ?? result.hostRoomUrl ?? null);
    } catch {
      alert('Erro ao criar sala de teleconsulta.');
    } finally {
      setCreatingRoom(false);
    }
  };

  const handleSign = async () => {
    if (!decision || !doctorId) return;
    setSigning(true);
    try {
      const laudoTexto = decision === 'APTO_COM_RESTRICAO'
        ? `${decision}: ${restriction}`
        : decision;
      try {
        await apiUpdateSolicitacao(params.id, { status: 'CONCLUIDO', laudoTexto, decision, restrictionNotes: decision === 'APTO_COM_RESTRICAO' ? restriction : undefined });
      } catch {
        console.error('Falha ao atualizar status da solicitação no backend.');
      }

      const signatureData = await apiFetch('/api/signature/generate', {
        method: 'POST',
        body: JSON.stringify({ examRequestId: params.id, doctorId }),
      });
      setSignatureUrl(signatureData.url);

      await apiFetch(`/api/signature/sign/${signatureData.asoDocumentId}`, {
        method: 'POST',
      });

      const pdfData = await apiFetch('/api/aso/generate', {
        method: 'POST',
        body: JSON.stringify({
          examRequestId: params.id,
          doctorId,
          decision,
          restrictionNotes: decision === 'APTO_COM_RESTRICAO' ? restriction : undefined,
        }),
      });
      setPdfUrl(pdfData.pdfUrl);

      setSigning(false);
    } catch {
      alert('Erro ao gerar assinatura.');
      setSigning(false);
    }
  };

  const decisionOptions: { value: Decision; label: string; Icon: typeof CheckCircleIcon; color: string; bg: string }[] = [
    { value: 'APTO', label: 'Apto', Icon: CheckCircleIcon, color: '#38a169', bg: 'rgba(56,161,105,0.15)' },
    { value: 'APTO_COM_RESTRICAO', label: 'Apto com Restrição', Icon: ExclamationTriangleIcon, color: '#f5a623', bg: 'rgba(245,166,35,0.15)' },
    { value: 'INAPTO', label: 'Inapto', Icon: XCircleIcon, color: '#e53e3e', bg: 'rgba(229,62,62,0.15)' },
  ];

  if (loading) {
    return <div className="page-center"><p style={{ color: 'var(--text-muted)' }}>Carregando...</p></div>;
  }

  if (!solicitacao) {
    return <div className="page-center"><p style={{ color: '#dc2626' }}>Solicitação não encontrada</p></div>;
  }

  const patient = solicitacao.patient;

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 420px', gap: '20px', minHeight: 'calc(100vh - 160px)' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
        <div className="card" style={{ flex: 1, position: 'relative', minHeight: '360px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
          {!videoRoomUrl ? (
            <div style={{ textAlign: 'center' }}>
              <VideoCameraIcon className="icon" style={{ width: '64px', height: '64px', marginBottom: '16px', color: 'var(--text-muted)' }} />
              <p style={{ color: 'var(--text-secondary)', marginBottom: '20px', fontSize: '14px' }}>
                Paciente aguardando na sala virtual
              </p>
              <button
                id="btn-create-room"
                className="btn btn-primary"
                onClick={handleCreateRoom}
                disabled={creatingRoom}
              >
                <VideoCameraIcon className="icon" />
                {creatingRoom ? 'Criando sala...' : 'Iniciar teleconsulta'}
              </button>
            </div>
          ) : (
            <div style={{ textAlign: 'center' }}>
              <VideoCameraIcon className="icon" style={{ width: '64px', height: '64px', marginBottom: '16px', color: 'var(--text-muted)' }} />
              <p style={{ color: 'var(--text-secondary)', marginBottom: '20px', fontSize: '14px' }}>
                Sala criada! Clique abaixo para entrar.
              </p>
              <a
                href={videoRoomUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-success"
                style={{ textDecoration: 'none' }}
              >
                <VideoCameraIcon className="icon" />
                Entrar na sala (médico)
              </a>
            </div>
          )}
        </div>

        <div className="card" style={{ padding: '16px 20px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontWeight: '700', fontSize: '16px' }}>{patient.name}</div>
              <div style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
                CPF: {patient.cpf} · {solicitacao.examPurpose} · CBO {patient.functionCboCode ?? '-'}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '12px', color: 'var(--text-muted)', marginTop: '2px' }}>
                <MapPinIcon className="icon icon-xs" />
                {solicitacao.clinic?.city ?? ''}/{solicitacao.clinic?.state ?? ''} · {solicitacao.clinic?.name ?? ''}
              </div>
            </div>
            <span className="priority-badge priority-city">
              <MapPinIcon className="icon" />
              Mesma Cidade
            </span>
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', overflowY: 'auto' }}>
        <div className="card" style={{ padding: '0' }}>
          <div style={{ display: 'flex', borderBottom: '1px solid var(--border-light)' }}>
            {([
              { id: 'exames', label: 'Exames', Icon: BeakerIcon },
              { id: 'anamnese', label: 'Anamnese', Icon: ClipboardDocumentListIcon },
              { id: 'notas', label: 'Notas', Icon: PencilSquareIcon },
            ] as const).map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                style={{
                  flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  gap: '6px', padding: '12px', background: 'transparent', border: 'none',
                  borderBottom: activeTab === tab.id ? '2px solid #3b6ff5' : '2px solid transparent',
                  color: activeTab === tab.id ? '#3b6ff5' : 'var(--text-secondary)',
                  fontSize: '13px', fontWeight: '600', cursor: 'pointer',
                }}
              >
                <tab.Icon className="icon icon-sm" />
                {tab.label}
              </button>
            ))}
          </div>

          <div style={{ padding: '20px' }}>
            {activeTab === 'exames' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {parsedExams && parsedExams.length > 0 ? (
                  parsedExams.flatMap((exam) =>
                    Object.entries(exam.parsedValues).map(([key, value]) => {
                      const status = getExamStatus(exam.type?.name ?? '', key, value);
                      return (
                        <div key={`${exam.id}-${key}`} style={{
                          display: 'flex', justifyContent: 'space-between',
                          padding: '10px 14px', borderRadius: '8px',
                          background: status === 'critical' ? 'rgba(229,62,62,0.08)' : status === 'attention' ? 'rgba(245,166,35,0.08)' : 'var(--bg-input)',
                          border: `1px solid ${status === 'critical' ? '#dc2626' : status === 'attention' ? '#f5a623' : 'var(--border-light)'}`,
                        }}>
                          <span style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
                            {exam.type?.name}: {key.replace(/_/g, ' ')}
                          </span>
                          <span style={{ fontSize: '13px', fontWeight: '700', color: 'var(--text-primary)' }}>
                            {value}
                          </span>
                        </div>
                      );
                    })
                  )
                ) : (
                  <p style={{ color: 'var(--text-muted)', fontSize: '13px', textAlign: 'center' }}>
                    Nenhum exame registrado ainda
                  </p>
                )}
              </div>
            )}

            {activeTab === 'anamnese' && (
              <div style={{ color: 'var(--text-secondary)', fontSize: '13px', lineHeight: '1.6' }}>
                {anamnese ? (
                  <>
                    {anamnese.queixas && <p style={{ marginBottom: '8px' }}><strong style={{ color: 'var(--text-primary)' }}>Queixas:</strong> {anamnese.queixas}</p>}
                    {anamnese.historicoMedico && <p style={{ marginBottom: '8px' }}><strong style={{ color: 'var(--text-primary)' }}>Histórico Médico:</strong> {anamnese.historicoMedico}</p>}
                    {anamnese.historicoOcupacional && <p style={{ marginBottom: '8px' }}><strong style={{ color: 'var(--text-primary)' }}>Histórico Ocupacional:</strong> {anamnese.historicoOcupacional}</p>}
                    {anamnese.medicamentos && <p style={{ marginBottom: '8px' }}><strong style={{ color: 'var(--text-primary)' }}>Medicamentos:</strong> {anamnese.medicamentos}</p>}
                    {anamnese.habitos && <p style={{ marginBottom: '8px' }}><strong style={{ color: 'var(--text-primary)' }}>Hábitos:</strong> {anamnese.habitos}</p>}
                  </>
                ) : (
                  <>
                    <p><strong style={{ color: 'var(--text-primary)' }}>Queixas:</strong> Nenhuma relatada</p>
                    <p style={{ marginTop: '8px' }}><strong style={{ color: 'var(--text-primary)' }}>Histórico:</strong> Sem histórico registrado.</p>
                    <p style={{ marginTop: '8px' }}><strong style={{ color: 'var(--text-primary)' }}>Medicamentos:</strong> Nenhum informado.</p>
                  </>
                )}
              </div>
            )}

            {activeTab === 'notas' && (
              <textarea
                id="clinical-notes"
                className="form-input"
                style={{ minHeight: '160px', resize: 'vertical' }}
                placeholder="Anotações clínicas (criptografadas em repouso)..."
                value={notes}
                onChange={e => setNotes(e.target.value)}
              />
            )}
          </div>
        </div>

        <div className="card">
          <h3 style={{ fontSize: '14px', fontWeight: '700', marginBottom: '16px', textTransform: 'uppercase', letterSpacing: '0.5px', color: 'var(--text-secondary)' }}>
            Decisão do ASO
          </h3>

          {(() => {
            const isConcluido = solicitacao?.status === 'CONCLUIDO';
            const asoExistente = (solicitacao as any)?.asoDocuments?.[0];
            if (isConcluido && asoExistente) {
              return (
                <div className="card" style={{ padding: 0, border: 'none', boxShadow: 'none', background: 'transparent' }}>
                  <h3 style={{ fontSize: '14px', fontWeight: '700', marginBottom: '16px', textTransform: 'uppercase', letterSpacing: '0.5px', color: 'var(--text-secondary)' }}>
                    ASO Emitido
                  </h3>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '16px', borderRadius: '10px', background: 'rgba(34,197,94,0.08)', border: '1px solid rgba(34,197,94,0.2)' }}>
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#16a34a" strokeWidth="2"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    <div>
                      <div style={{ fontWeight: 700, color: '#16a34a' }}>
                        {asoExistente.decision === 'APTO' ? 'Apto' :
                         asoExistente.decision === 'INAPTO' ? 'Inapto' : 'Apto com Restrição'}
                      </div>
                      {asoExistente.restrictionNotes && (
                        <div style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
                          Restrição: {asoExistente.restrictionNotes}
                        </div>
                      )}
                      {asoExistente.validUntil && (
                        <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
                          Válido até: {new Date(asoExistente.validUntil).toLocaleDateString('pt-BR')}
                        </div>
                      )}
                    </div>
                  </div>
                  {asoExistente.pdfUrl && (
                    <a href={asoExistente.pdfUrl} target="_blank" rel="noopener noreferrer" className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', marginTop: '12px', textDecoration: 'none' }}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ marginRight: '8px' }}><path d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                      Baixar ASO
                    </a>
                  )}
                </div>
              );
            }
            return (
              <>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '16px' }}>
                {decisionOptions.map((opt) => (
                  <button
                    key={opt.value}
                    id={`btn-decision-${opt.value.toLowerCase()}`}
                    onClick={() => setDecision(opt.value)}
                    style={{
                      display: 'flex', alignItems: 'center', gap: '10px',
                      padding: '12px 16px', borderRadius: '10px',
                      background: decision === opt.value ? opt.bg : 'var(--bg-input)',
                      border: `1px solid ${decision === opt.value ? opt.color : 'var(--border-light)'}`,
                      color: decision === opt.value ? opt.color : 'var(--text-secondary)',
                      fontSize: '14px', fontWeight: '600', cursor: 'pointer', textAlign: 'left',
                      transition: 'all 0.2s',
                    }}
                  >
                    <opt.Icon className="icon icon-sm" />
                    {opt.label}
                  </button>
                ))}
              </div>

              {decision === 'APTO_COM_RESTRICAO' && (
                <div className="form-group">
                  <label className="form-label">Descrição da Restrição *</label>
                  <textarea
                    id="restriction-notes"
                    className="form-input"
                    style={{ minHeight: '80px', resize: 'vertical' }}
                    placeholder="Descreva as restrições..."
                    value={restriction}
                    onChange={e => setRestriction(e.target.value)}
                  />
                </div>
              )}

              <button
                id="btn-sign-aso"
                className="btn btn-primary"
                style={{ width: '100%', justifyContent: 'center', marginTop: '8px' }}
                onClick={handleSign}
                disabled={!decision || signing || (decision === 'APTO_COM_RESTRICAO' && !restriction) || solicitacao?.status === 'CONCLUIDO' || !videoRoomUrl}
              >
                {signing ? (
                  <><ClockIcon className="icon" /> Processando...</>
                ) : signatureUrl ? (
                  <><LinkIcon className="icon" /> Acessar Assinatura</>
                ) : (
                  <><PencilSquareIcon className="icon" /> Emitir ASO</>
                )}
              </button>

              {pdfUrl && (
                <div style={{ marginTop: '16px', textAlign: 'center' }}>
                  <a
                    href={pdfUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-success"
                    style={{ width: '100%', justifyContent: 'center' }}
                  >
                    <DocumentTextIcon className="icon" />
                    Baixar ASO Assinado
                  </a>
                </div>
              )}

              {!videoRoomUrl && !isConcluido && (
                <p style={{ fontSize: '12px', color: '#e53e3e', textAlign: 'center', marginTop: '8px' }}>
                  A sala de teleconsulta precisa ser criada antes de emitir o ASO.
                </p>
              )}
              {!decision && videoRoomUrl && (
                <p style={{ fontSize: '12px', color: 'var(--text-muted)', textAlign: 'center', marginTop: '8px' }}>
                  Selecione uma decisão para habilitar a assinatura
                </p>
              )}
            </>
          )})()}
        </div>
      </div>
    </div>
  );
}
