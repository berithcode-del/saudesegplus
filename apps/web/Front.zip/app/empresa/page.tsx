'use client';
import { useState, useEffect } from 'react';
import GreetingCompany from '../../components/empresa/GreetingCompany';
import CompanyStats from '../../components/empresa/CompanyStats';
import RecentInvitesTable from '../../components/empresa/RecentInvitesTable';
import QuickActionsCompany from '../../components/empresa/QuickActionsCompany';
import InvitesChart from '../../components/empresa/InvitesChart';
import ScheduleCalendar from '../../components/dashboard/ScheduleCalendar';
import { apiGetEvents } from '../../lib/api';

const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL ?? 'http://localhost:3001';

interface DashboardStats {
  total: number;
  sent: number;
  opened: number;
  inProgress: number;
  completed: number;
  expired: number;
}

interface Invite {
  id: string;
  status: string;
  examType: string;
  createdAt: string;
  expiresAt: string;
  expectedCpf?: string;
  expectedEmail?: string;
  timelineEvents: { eventType: string; occurredAt: string }[];
}

export default function EmpresaDashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    total: 0,
    sent: 0,
    opened: 0,
    inProgress: 0,
    completed: 0,
    expired: 0,
  });
  const [recentInvites, setRecentInvites] = useState<Invite[]>([]);
  const [loading, setLoading] = useState(true);
  const [companyName, setCompanyName] = useState<string>('');
  const [companyId, setCompanyId] = useState<string>('');
  const [events, setEvents] = useState<any[]>([]);

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        const companiesRes = await fetch(`${BACKEND_URL}/api/company`);
        const companiesResult = await companiesRes.json();
        const companies = companiesResult.data ?? [];
        const companyId = companies.length > 0 ? companies[0].id : null;
        
        if (companies.length > 0) {
          const c = companies[0];
          setCompanyName(c.tradeName || c.legalName || 'Empresa');
          setCompanyId(c.id);
        }

        if (!companyId) {
          setLoading(false);
          return;
        }

        const [statsRes, invitesRes, eventsData] = await Promise.all([
          fetch(`${BACKEND_URL}/api/company/${companyId}/dashboard`),
          fetch(`${BACKEND_URL}/api/company/${companyId}/invites`),
          apiGetEvents('company', companyId),
        ]);

        const statsResult = await statsRes.json();
        const invitesResult = await invitesRes.json();
        if (eventsData) setEvents(eventsData);

        if (statsResult.data) {
          setStats(statsResult.data);
        }

        const invites = invitesResult.data ?? [];
        setRecentInvites(Array.isArray(invites) ? invites : []);
      } catch (err) {
        console.error('Erro ao buscar dashboard:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboard();
  }, []);

  if (loading) {
    return <div style={{ padding: '32px', textAlign: 'center', color: '#6b7280' }}>Carregando painel...</div>;
  }

  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: 'minmax(0, 8fr) minmax(0, 4fr)',
        gap: '24px',
        alignItems: 'start',
        overflow: 'visible',
      }}
    >
      {/* ── Coluna Esquerda (70%) ────────────── */}
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '24px',
          overflow: 'visible',
          paddingTop: '60px',
        }}
      >
        <GreetingCompany name={companyName} />
        <CompanyStats stats={stats} />
        <RecentInvitesTable invites={recentInvites} />
      </div>

      {/* ── Coluna Direita (30%) ─────────────── */}
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '24px',
          paddingTop: '60px',
        }}
      >
        <QuickActionsCompany />
        <InvitesChart invites={recentInvites} />
        <ScheduleCalendar
          ownerType="company"
          ownerId={companyId}
          events={events}
          onEventCreated={() => {
            if (companyId) apiGetEvents('company', companyId).then(res => setEvents(res));
          }}
        />
      </div>
    </div>
  );
}
