const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL ?? 'http://localhost:3001';

export async function apiGetExamTypes(): Promise<{ data: any }> {
  const res = await fetch(`${BACKEND_URL}/api/exams/types`);
  return res.json();
}

export async function apiGetRequiredExams(cboCode: string): Promise<{ data: any }> {
  const res = await fetch(`${BACKEND_URL}/api/exams/required-by-cbo?cbo=${encodeURIComponent(cboCode)}`);
  return res.json();
}

export async function apiGetMedicoProfile(id: string): Promise<{ data: any }> {
  const res = await fetch(`${BACKEND_URL}/api/medicos/${id}/perfil`);
  return res.json();
}

export async function apiGetMedicoSolicitacoes(id: string, startDate?: string, endDate?: string): Promise<{ data: any }> {
  let url = `${BACKEND_URL}/api/medicos/${id}/solicitacoes`;
  const params = new URLSearchParams();
  if (startDate) params.append('startDate', startDate);
  if (endDate) params.append('endDate', endDate);
  
  if (params.toString()) {
    url += `?${params.toString()}`;
  }
  
  const res = await fetch(url);
  return res.json();
}

export async function apiGetEvents(ownerType: string, ownerId: string, startDate?: string, endDate?: string) {
  const params = new URLSearchParams({ ownerType, ownerId });
  if (startDate) params.append('startDate', startDate);
  if (endDate) params.append('endDate', endDate);
  
  const response = await fetch(`${BACKEND_URL}/api/calendar?${params.toString()}`);
  if (!response.ok) throw new Error('Falha ao buscar eventos de calendário');
  const data = await response.json();
  return data.data || [];
}

export async function apiCreateEvent(payload: { title: string; type: string; date: string; ownerType: string; ownerId: string }) {
  const response = await fetch(`${BACKEND_URL}/api/calendar`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!response.ok) throw new Error('Falha ao criar evento no calendário');
  const data = await response.json();
  return data.data;
}
