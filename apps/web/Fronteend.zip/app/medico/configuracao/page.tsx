'use client';
import { useEffect, useState } from 'react';
import { ArrowPathIcon, CheckCircleIcon, LockClosedIcon } from '@heroicons/react/24/outline';
import { apiListMedicos, apiFetch } from '../../lib/api';
import FaqHelp from '../../../components/FaqHelp';

interface Medico {
  id: string;
  name: string;
  crmNumber: string;
  crmState: string;
  city?: string;
  state?: string;
  specialties?: string;
}

export default function MedicoConfiguracaoPage() {
  const [medicos, setMedicos] = useState<Medico[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState('');

  const [pwForm, setPwForm] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
  const [pwSaving, setPwSaving] = useState(false);
  const [pwMessage, setPwMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    const saved = typeof window !== 'undefined' ? window.localStorage.getItem('doctorId') ?? '' : '';
    setSelectedId(saved);
    fetchMedicos();
  }, []);

  const fetchMedicos = async () => {
    setLoading(true);
    try {
      const r = await apiListMedicos();
      const list = Array.isArray(r) ? r : (r as any)?.data?.data ?? (r as any)?.data ?? [];
      setMedicos(Array.isArray(list) ? list : []);
    } catch {
      setMedicos([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSelect = (id: string) => {
    setSelectedId(id);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('doctorId', id);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pwForm.newPassword !== pwForm.confirmPassword) {
      setPwMessage({ type: 'error', text: 'As senhas não conferem' });
      return;
    }
    if (pwForm.newPassword.length < 6) {
      setPwMessage({ type: 'error', text: 'A nova senha deve ter no mínimo 6 caracteres' });
      return;
    }
    setPwSaving(true);
    setPwMessage(null);
    try {
      await apiFetch('/api/auth/change-password', {
        method: 'POST',
        body: JSON.stringify({
          currentPassword: pwForm.currentPassword,
          newPassword: pwForm.newPassword,
        }),
      });
      setPwMessage({ type: 'success', text: 'Senha alterada com sucesso!' });
      setPwForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
    } catch (err: any) {
      setPwMessage({ type: 'error', text: err.message || 'Erro ao alterar senha' });
    } finally {
      setPwSaving(false);
    }
  };

  return (
    <>
      <div className="page-header">
        <h2>Configuração do Médico</h2>
        <p>Selecione o médico ativo para acessar as funcionalidades do painel</p>
      </div>

      <div className="card">
        <div style={{ display: 'flex', gap: '12px', alignItems: 'center', marginBottom: '20px' }}>
          <h3 style={{ fontSize: '16px', fontWeight: 600, flex: 1 }}>Médicos Disponíveis</h3>
          <button className="btn btn-ghost" onClick={fetchMedicos}>
            <ArrowPathIcon className="icon icon-sm" /> Recarregar
          </button>
        </div>

        {loading ? (
          <p style={{ color: 'var(--text-muted)', textAlign: 'center', padding: '40px' }}>Carregando...</p>
        ) : medicos.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '40px' }}>
            <p style={{ color: 'var(--text-secondary)' }}>Nenhum médico cadastrado.</p>
            <p style={{ color: 'var(--text-muted)', fontSize: '14px', marginTop: '8px' }}>
              Solicite ao administrador que cadastre médicos no sistema.
            </p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {medicos.map((m) => {
              const isSelected = m.id === selectedId;
              return (
                <button
                  key={m.id}
                  onClick={() => handleSelect(m.id)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    padding: '14px 16px',
                    border: `2px solid ${isSelected ? 'var(--accent-primary)' : 'var(--border-light)'}`,
                    borderRadius: '10px',
                    background: isSelected ? 'rgba(79,70,229,0.05)' : 'var(--card-bg)',
                    cursor: 'pointer',
                    textAlign: 'left',
                    width: '100%',
                    transition: 'all 0.15s',
                  }}
                >
                  <div style={{
                    width: '20px', height: '20px', borderRadius: '50%',
                    border: `2px solid ${isSelected ? 'var(--accent-primary)' : 'var(--border-color)'}`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    flexShrink: 0,
                  }}>
                    {isSelected && <CheckCircleIcon style={{ width: '16px', height: '16px', color: 'var(--accent-primary)' }} />}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{m.name}</div>
                    <div style={{ fontSize: '13px', color: 'var(--text-muted)' }}>
                      CRM {m.crmNumber}/{m.crmState}
                      {m.specialties ? ` — ${m.specialties}` : ''}
                      {m.city ? ` — ${m.city}` : ''}
                    </div>
                  </div>
                  {isSelected && (
                    <span style={{
                      fontSize: '12px', fontWeight: 600, color: 'var(--accent-primary)',
                      background: 'rgba(79,70,229,0.1)', padding: '4px 10px', borderRadius: '6px',
                    }}>
                      Ativo
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        )}
      </div>

      {selectedId && (
        <div className="card" style={{ marginTop: '16px' }}>
          <div style={{
            display: 'flex', alignItems: 'center', gap: '8px',
            color: '#16a34a', fontWeight: 600, fontSize: '14px',
          }}>
            <CheckCircleIcon className="icon" />
            Médico configurado com sucesso. Acesse as páginas do painel médico.
          </div>
        </div>
      )}

      <div className="card" style={{ marginTop: '16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '16px' }}>
          <LockClosedIcon className="icon" style={{ color: 'var(--accent-primary)' }} />
          <h3 style={{ fontSize: '16px', fontWeight: 600, margin: 0 }}>Alterar Senha</h3>
        </div>
        <p style={{ fontSize: '13px', color: 'var(--text-secondary)', marginBottom: '16px' }}>
          Insira a senha fornecida pelo sistema e defina uma nova senha.
        </p>
        <form onSubmit={handleChangePassword} style={{ maxWidth: '400px' }}>
          <div className="form-group">
            <label className="form-label">Senha Atual</label>
            <input className="form-input" type="password" required
              value={pwForm.currentPassword}
              onChange={e => setPwForm({ ...pwForm, currentPassword: e.target.value })}
              placeholder="Senha fornecida pelo sistema" />
          </div>
          <div className="form-group">
            <label className="form-label">Nova Senha</label>
            <input className="form-input" type="password" required minLength={6}
              value={pwForm.newPassword}
              onChange={e => setPwForm({ ...pwForm, newPassword: e.target.value })}
              placeholder="Mínimo 6 caracteres" />
          </div>
          <div className="form-group">
            <label className="form-label">Confirmar Nova Senha</label>
            <input className="form-input" type="password" required minLength={6}
              value={pwForm.confirmPassword}
              onChange={e => setPwForm({ ...pwForm, confirmPassword: e.target.value })}
              placeholder="Repita a nova senha" />
          </div>
          {pwMessage && (
            <div style={{
              padding: '10px 14px', borderRadius: '10px', marginBottom: '12px', fontSize: '13px', fontWeight: 500,
              background: pwMessage.type === 'success' ? '#dcfce7' : '#fef2f2',
              color: pwMessage.type === 'success' ? '#16a34a' : '#dc2626',
            }}>
              {pwMessage.text}
            </div>
          )}
          <button type="submit" className="btn btn-primary" disabled={pwSaving}>
            {pwSaving ? 'Alterando...' : 'Alterar Senha'}
          </button>
        </form>
      </div>

      <FaqHelp perfil="MEDICO" />
    </>
  );
}
