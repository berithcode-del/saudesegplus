'use client';
import React from 'react';
import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import {
  CheckCircleIcon,
  ArrowRightIcon,
  ChevronDownIcon,
  ChevronUpIcon,
  ClockIcon,
  MapPinIcon,
  DocumentTextIcon,
  VideoCameraIcon,
  ClipboardDocumentCheckIcon,
  PencilSquareIcon,
  ArrowUpTrayIcon,
  SignalIcon,
} from '@heroicons/react/24/outline';

const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL ?? 'http://localhost:3001';

interface ProcessoData {
  id?: string;
  status?: string;
  paciente?: { nome?: string; cpf?: string };
  empresa?: { nome?: string };
  clinica?: { nome?: string; endereco?: string; latitude?: number; longitude?: number };
  proximaAcao?: { tipo: string; titulo?: string; descricao?: string };
  timeline?: Array<{ eventType?: string; descricao?: string; ocorridoEm?: string; occurredAt?: string }>;
  teleconsulta?: { disponivel: boolean; linkSala: string | null };
  progresso?: Array<{ label: string; concluido: boolean; ativo: boolean }>;
}

const acaoConfig: Record<string, { label: string; Icon: typeof ArrowRightIcon }> = {
  CONFIRMAR_DADOS: { label: 'Confirmar dados', Icon: ClipboardDocumentCheckIcon },
  ENVIAR_DOCUMENTOS: { label: 'Enviar documentos', Icon: ArrowUpTrayIcon },
  RESPONDER_QUESTIONARIO: { label: 'Responder questionário', Icon: PencilSquareIcon },
  ENTRAR_TELECONSULTA: { label: 'Entrar na teleconsulta', Icon: VideoCameraIcon },
  BAIXAR_ASO: { label: 'Baixar ASO', Icon: DocumentTextIcon },
};

function WaitingRoom({ status, teleconsultaUrl }: { status: string; teleconsultaUrl: string | null }) {
  const isBeingCalled = status === 'EM_ATENDIMENTO_MEDICO' && teleconsultaUrl;
  const isWaiting = status === 'NA_FILA_MEDICA' || (status === 'EM_ATENDIMENTO_MEDICO' && !teleconsultaUrl);

  if (isBeingCalled && teleconsultaUrl) {
    return (
      <div style={{ marginBottom: '20px' }}>
        {/* Banner pulsante de chamada */}
        <div style={{
          background: 'linear-gradient(135deg, #059669, #10b981)',
          borderRadius: '20px',
          padding: '28px 24px',
          textAlign: 'center',
          marginBottom: '16px',
          boxShadow: '0 8px 32px rgba(5,150,105,0.35)',
          animation: 'pulse-glow 2s infinite',
        }}>
          <div style={{ fontSize: '52px', marginBottom: '10px' }}>📹</div>
          <h2 style={{ color: 'white', fontSize: '22px', fontWeight: 800, marginBottom: '6px' }}>
            O médico está te chamando!
          </h2>
          <p style={{ color: 'rgba(255,255,255,0.85)', fontSize: '14px', marginBottom: '24px' }}>
            Sua teleconsulta está pronta. Entre agora para falar com o médico.
          </p>
          <a
            href={teleconsultaUrl}
            target="_blank"
            rel="noopener noreferrer"
            style={{
              display: 'inline-flex', alignItems: 'center', gap: '10px',
              background: 'white', color: '#059669',
              fontWeight: 700, fontSize: '16px',
              padding: '14px 32px', borderRadius: '14px',
              textDecoration: 'none',
              boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
            }}
          >
            <VideoCameraIcon style={{ width: '20px', height: '20px' }} />
            Entrar na Teleconsulta
          </a>
        </div>

        {/* Iframe embutido */}
        <div style={{
          background: 'white', borderRadius: '20px',
          border: '1px solid #e5e7eb', overflow: 'hidden',
          boxShadow: '0 2px 12px rgba(31,38,135,0.08)',
        }}>
          <div style={{
            padding: '12px 16px', background: '#f0fdf4',
            borderBottom: '1px solid #d1fae5',
            display: 'flex', alignItems: 'center', gap: '8px',
          }}>
            <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#10b981', animation: 'blink 1s infinite' }} />
            <span style={{ fontSize: '13px', fontWeight: 600, color: '#065f46' }}>Sala de Teleconsulta Ativa</span>
          </div>
          <iframe
            src={teleconsultaUrl}
            allow="camera; microphone; fullscreen; display-capture; autoplay"
            style={{ width: '100%', height: '480px', border: 'none' }}
            title="Teleconsulta"
          />
        </div>
      </div>
    );
  }

  if (isWaiting) {
    return (
      <div style={{
        background: 'white', borderRadius: '20px',
        padding: '36px 24px',
        boxShadow: '0 2px 12px rgba(31,38,135,0.08)',
        border: '1px solid #e5e7eb',
        textAlign: 'center', marginBottom: '20px',
      }}>
        {/* Spinner animado */}
        <div style={{
          width: '72px', height: '72px', borderRadius: '50%',
          background: 'rgba(79,70,229,0.08)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          margin: '0 auto 20px', position: 'relative',
        }}>
          <div style={{
            position: 'absolute', inset: 0, borderRadius: '50%',
            border: '3px solid #4f46e5', borderTopColor: 'transparent',
            animation: 'spin 1.2s linear infinite',
          }} />
          <SignalIcon style={{ width: '32px', height: '32px', color: '#4f46e5' }} />
        </div>

        <h2 style={{ fontSize: '20px', fontWeight: 700, color: '#1e1b4b', marginBottom: '10px' }}>
          {status === 'NA_FILA_MEDICA' ? 'Você está na fila médica' : 'Médico analisando seus exames'}
        </h2>
        <p style={{ fontSize: '14px', color: '#6b7280', lineHeight: 1.7, marginBottom: '24px', maxWidth: '320px', margin: '0 auto 24px' }}>
          {status === 'NA_FILA_MEDICA'
            ? 'Um médico do trabalho irá analisar seus exames em breve. Fique nesta tela — você será notificado assim que a videochamada estiver disponível.'
            : 'O médico está revisando seus resultados. Aguarde — ele iniciará a videochamada em instantes.'}
        </p>

        {/* Badge online */}
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: '8px',
          padding: '10px 20px', borderRadius: '50px',
          background: 'rgba(34,197,94,0.08)',
          border: '1px solid rgba(34,197,94,0.2)',
          fontSize: '13px', fontWeight: 600, color: '#16a34a',
          marginBottom: '16px',
        }}>
          <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#22c55e', animation: 'blink 1.5s infinite' }} />
          Você está online e disponível
        </div>

        <p style={{ fontSize: '12px', color: '#9ca3af', marginTop: '8px' }}>
          ⏱ Esta página atualiza automaticamente a cada 5 segundos
        </p>
      </div>
    );
  }

  return null;
}

export default function ProcessoPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = React.use(params);
  const router = useRouter();
  const [data, setData] = useState<ProcessoData | null>(null);
  const [loading, setLoading] = useState(true);
  const [timelineOpen, setTimelineOpen] = useState(false);

  const fetchProcesso = useCallback(async () => {
    const portalToken = sessionStorage.getItem('portalToken');
    if (!portalToken) {
      router.replace(`/p/${token}`);
      return;
    }
    try {
      const res = await fetch(`${BACKEND_URL}/api/portal/processo`, {
        headers: { Authorization: `Bearer ${portalToken}` },
      });
      if (res.status === 401) {
        sessionStorage.removeItem('portalToken');
        router.replace(`/p/${token}`);
        return;
      }
      const json = await res.json();
      if (json.data) setData(json.data);
    } catch {
      // polling vai tentar de novo
    } finally {
      setLoading(false);
    }
  }, [token, router]);

  useEffect(() => {
    fetchProcesso();
    // Polling a cada 5 segundos para detectar chamada do médico
    const interval = setInterval(fetchProcesso, 5000);
    return () => clearInterval(interval);
  }, [fetchProcesso]);

  useEffect(() => {
    // Envia heartbeat a cada 15 segundos para manter o status online na fila médica
    const sendHeartbeat = async () => {
      const portalToken = sessionStorage.getItem('portalToken');
      if (!portalToken) return;
      try {
        await fetch(`${BACKEND_URL}/api/portal/heartbeat`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${portalToken}` },
        });
      } catch (err) {
        console.error('Falha ao enviar heartbeat:', err);
      }
    };
    sendHeartbeat();
    const heartbeatInterval = setInterval(sendHeartbeat, 15000);
    return () => clearInterval(heartbeatInterval);
  }, []);

  const handleCta = () => {
    if (!data?.proximaAcao) return;
    const tipo = data.proximaAcao.tipo;
    const map: Record<string, string> = {
      CONFIRMAR_DADOS: `/p/${token}/confirmar`,
      ENVIAR_DOCUMENTOS: `/p/${token}/documentos`,
      RESPONDER_QUESTIONARIO: `/p/${token}/questionario`,
      ENTRAR_TELECONSULTA: `/p/${token}/teleconsulta`,
      BAIXAR_ASO: `/p/${token}/aso`,
    };
    const path = map[tipo];
    if (path) router.push(path);
  };

  const progresso = data?.progresso ?? [];
  const firstIncompleteIndex = progresso.findIndex(p => !p.concluido);
  const etapaIndex = firstIncompleteIndex === -1 ? Math.max(0, progresso.length - 1) : firstIncompleteIndex;
  const acao = data?.proximaAcao;
  const config = acao ? acaoConfig[acao.tipo] : null;
  const isCtaClickable = !!config && !['AGUARDAR_RESULTADOS', 'AGUARDAR_MEDICO'].includes(acao?.tipo ?? '');
  const isWaitingForDoctor = ['NA_FILA_MEDICA', 'EM_ATENDIMENTO_MEDICO'].includes(data?.status ?? '');
  const teleconsultaUrl = data?.teleconsulta?.linkSala ?? null;

  if (loading) {
    return <div style={{ textAlign: 'center', padding: '60px 0', color: '#9ca3af' }}>Carregando...</div>;
  }

  return (
    <div>
      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes blink { 0%,100% { opacity:1; } 50% { opacity:0.3; } }
        @keyframes pulse-glow { 0%,100% { box-shadow:0 8px 32px rgba(5,150,105,0.35); } 50% { box-shadow:0 8px 52px rgba(5,150,105,0.6); } }
        @keyframes pulse-dot { 0%,100% { box-shadow:0 0 0 4px rgba(59,111,245,0.2); } 50% { box-shadow:0 0 0 8px rgba(59,111,245,0.1); } }
      `}</style>

      {/* Barra de Progresso */}
      <div style={{
        background: 'white', borderRadius: '16px', padding: '20px 16px',
        boxShadow: '0 2px 12px rgba(31,38,135,0.08)', border: '1px solid #e5e7eb', marginBottom: '20px',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', position: 'relative' }}>
          <div style={{ position: 'absolute', top: '12px', left: '8%', right: '8%', height: '3px', background: '#e5e7eb', zIndex: 0 }} />
          <div style={{
            position: 'absolute', top: '12px', left: '8%', height: '3px', background: '#7c3aed', zIndex: 0,
            width: progresso.length > 1 ? `${(etapaIndex / (progresso.length - 1)) * 84}%` : '0%',
            transition: 'width 0.4s ease',
          }} />
          {progresso.map((p, i) => {
            const concluida = p.concluido;
            const atual = i === etapaIndex;
            return (
              <div key={p.label} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px', zIndex: 1, width: `${100 / progresso.length}%` }}>
                <div style={{
                  width: '24px', height: '24px', borderRadius: '50%',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: '11px', fontWeight: 700, color: 'white',
                  background: concluida ? '#7c3aed' : atual ? '#3b6ff5' : '#d1d5db',
                  animation: atual ? 'pulse-dot 1.5s infinite' : 'none',
                }}>
                  {concluida ? '✓' : i + 1}
                </div>
                <span style={{ fontSize: '9px', fontWeight: 600, color: concluida ? '#7c3aed' : atual ? '#3b6ff5' : '#9ca3af', textAlign: 'center', lineHeight: 1.2 }}>
                  {p.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Sala de Espera / Teleconsulta */}
      {isWaitingForDoctor && <WaitingRoom status={data?.status ?? ''} teleconsultaUrl={teleconsultaUrl} />}

      {/* Card de Próxima Ação (oculto quando teleconsulta está ativa) */}
      {!(isWaitingForDoctor && teleconsultaUrl) && (
        <div style={{
          background: 'white', borderRadius: '20px', padding: '28px 24px',
          boxShadow: '0 2px 12px rgba(31,38,135,0.08)', border: '1px solid #e5e7eb',
          textAlign: 'center', marginBottom: '20px',
        }}>
          {config ? (
            <config.Icon style={{ width: '48px', height: '48px', color: '#4f46e5', marginBottom: '16px' }} />
          ) : (
            <ClockIcon style={{ width: '48px', height: '48px', color: '#9ca3af', marginBottom: '16px' }} />
          )}
          <h2 style={{ fontSize: '18px', fontWeight: 700, color: '#1e1b4b', marginBottom: '6px' }}>
            {acao?.titulo ?? 'Próxima ação'}
          </h2>
          <p style={{ fontSize: '14px', color: '#6b7280', marginBottom: '16px', lineHeight: 1.5 }}>
            {acao?.descricao ?? 'Aguardando atualização do processo.'}
          </p>

          {data?.clinica && (
            <div style={{ padding: '12px 14px', borderRadius: '12px', background: 'rgba(79,70,229,0.05)', border: '1px solid rgba(79,70,229,0.12)', marginBottom: '16px', textAlign: 'left' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '8px' }}>
                <MapPinIcon style={{ width: '16px', height: '16px', color: '#4f46e5', flexShrink: 0, marginTop: '2px' }} />
                <div>
                  <div style={{ fontSize: '13px', fontWeight: 600, color: '#1e1b4b' }}>{data.clinica.nome}</div>
                  {data.clinica.endereco && <div style={{ fontSize: '12px', color: '#6b7280' }}>{data.clinica.endereco}</div>}
                </div>
              </div>
            </div>
          )}

          {config && isCtaClickable ? (
            <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }} onClick={handleCta}>
              {config.label}
              <ArrowRightIcon style={{ width: '16px', height: '16px' }} />
            </button>
          ) : acao && ['AGUARDAR_RESULTADOS', 'AGUARDAR_MEDICO'].includes(acao.tipo) ? (
            <div style={{ padding: '12px 14px', borderRadius: '12px', background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.2)', fontSize: '13px', color: '#d97706' }}>
              <ClockIcon style={{ width: '16px', height: '16px', verticalAlign: 'middle', marginRight: '6px' }} />
              Acompanhando...
            </div>
          ) : null}
        </div>
      )}

      {/* Timeline */}
      {data?.timeline && data.timeline.length > 0 && (
        <div style={{ background: 'white', borderRadius: '16px', border: '1px solid #e5e7eb', overflow: 'hidden' }}>
          <button onClick={() => setTimelineOpen(!timelineOpen)} style={{ width: '100%', padding: '16px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: 'transparent', border: 'none', cursor: 'pointer', fontSize: '14px', fontWeight: 600, color: '#1e1b4b', fontFamily: 'inherit' }}>
            <span>Ver histórico</span>
            {timelineOpen ? <ChevronUpIcon style={{ width: '18px', height: '18px', color: '#6b7280' }} /> : <ChevronDownIcon style={{ width: '18px', height: '18px', color: '#6b7280' }} />}
          </button>
          {timelineOpen && (
            <div style={{ padding: '0 20px 20px' }}>
              <div style={{ position: 'relative' }}>
                <div style={{ position: 'absolute', left: '8px', top: '4px', bottom: '4px', width: '2px', background: '#e5e7eb' }} />
                {data.timeline.map((evento, i) => (
                  <div key={i} style={{ display: 'flex', gap: '14px', paddingBottom: '16px', position: 'relative' }}>
                    <div style={{ width: '18px', height: '18px', borderRadius: '50%', background: '#7c3aed', flexShrink: 0, zIndex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <CheckCircleIcon style={{ width: '10px', height: '10px', color: 'white' }} />
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: '13px', fontWeight: 600, color: '#1e1b4b', marginBottom: '2px' }}>
                        {evento.descricao ?? evento.eventType}
                      </div>
                      <div style={{ fontSize: '12px', color: '#9ca3af' }}>
                        {new Date((evento.ocorridoEm ?? evento.occurredAt) as string).toLocaleString('pt-BR')}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
