'use client';
import React from 'react';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeftIcon, ArrowRightIcon, CheckCircleIcon } from '@heroicons/react/24/outline';

const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL ?? 'http://localhost:3001';

const perguntas = [
  { campo: 'queixas', pergunta: 'Você tem alguma queixa de saúde?', placeholder: 'Descreva suas queixas, se houver...' },
  { campo: 'doencasPrevias', pergunta: 'Você tem alguma doença?', placeholder: 'Liste doenças pré-existentes, se houver...' },
  { campo: 'medicamentosEmUso', pergunta: 'Usa algum medicamento?', placeholder: 'Quais medicamentos você usa?' },
  { campo: 'alergiasConhecidas', pergunta: 'Tem alergias?', placeholder: 'Descreva suas alergias conhecidas...' },
  { campo: 'cirurgiasPrevias', pergunta: 'Já passou por cirurgia?', placeholder: 'Cite as cirurgias pelas quais já passou...' },
  { campo: 'observacoes', pergunta: 'Alguma observação?', placeholder: 'Observações adicionais...' },
];

export default function QuestionarioPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = React.use(params);
  const router = useRouter();
  const [passo, setPasso] = useState(0);
  const [respostas, setRespostas] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const current = perguntas[passo]!;
  const isLast = passo === perguntas.length - 1;
  const progress = ((passo + 1) / perguntas.length) * 100;

  const handleChange = (value: string) => {
    setRespostas(prev => ({ ...prev, [current.campo]: value }));
  };

  const handleNext = () => {
    if (passo < perguntas.length - 1) setPasso(p => p + 1);
  };

  const handlePrev = () => {
    if (passo > 0) setPasso(p => p - 1);
  };

  const handleSubmit = async () => {
    setSaving(true);
    setError('');
    try {
      const portalToken = sessionStorage.getItem('portalToken');
      const processId = sessionStorage.getItem('processId');
      const res = await fetch(`${BACKEND_URL}/api/portal/questionario`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${portalToken}`,
        },
        body: JSON.stringify(respostas),
      });
      if (!res.ok) throw new Error('Erro ao salvar questionário.');
      router.push(`/p/${token}/processo`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao salvar.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      {/* Barra de progresso */}
      <div style={{
        background: 'white',
        borderRadius: '12px',
        padding: '16px',
        boxShadow: '0 2px 12px rgba(31,38,135,0.08)',
        border: '1px solid #e5e7eb',
        marginBottom: '20px',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
          <span style={{ fontSize: '12px', fontWeight: 600, color: '#6b7280' }}>
            Pergunta {passo + 1} de {perguntas.length}
          </span>
          <span style={{ fontSize: '12px', fontWeight: 600, color: '#4f46e5' }}>
            {Math.round(progress)}%
          </span>
        </div>
        <div style={{
          width: '100%', height: '6px', background: '#e5e7eb',
          borderRadius: '3px', overflow: 'hidden',
        }}>
          <div style={{
            height: '100%', background: '#7c3aed', borderRadius: '3px',
            transition: 'width 0.3s ease', width: `${progress}%`,
          }} />
        </div>
      </div>

      {/* Pergunta */}
      <div style={{
        background: 'white',
        borderRadius: '20px',
        padding: '28px 24px',
        boxShadow: '0 2px 12px rgba(31,38,135,0.08)',
        border: '1px solid #e5e7eb',
      }}>
        {error && (
          <div style={{
            padding: '12px 14px', borderRadius: '12px',
            background: 'rgba(239,68,68,0.08)',
            border: '1px solid rgba(239,68,68,0.25)',
            color: '#dc2626', fontSize: '13px',
            marginBottom: '16px',
          }}>
            {error}
          </div>
        )}

        <div style={{
          width: '44px', height: '44px', borderRadius: '12px',
          background: 'rgba(79,70,229,0.1)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          marginBottom: '16px',
        }}>
          <span style={{ fontSize: '18px', fontWeight: 700, color: '#4f46e5' }}>{passo + 1}</span>
        </div>

        <h3 style={{ fontSize: '18px', fontWeight: 700, color: '#1e1b4b', marginBottom: '20px' }}>
          {current!.pergunta}
        </h3>

        <textarea
          className="form-input"
          style={{ minHeight: '120px', resize: 'vertical' }}
          placeholder={current!.placeholder}
          value={respostas[current!.campo] ?? ''}
          onChange={(e) => handleChange(e.target.value)}
        />

        <div style={{ display: 'flex', gap: '12px', marginTop: '24px' }}>
          {passo > 0 && (
            <button className="btn btn-ghost" onClick={handlePrev}>
              <ArrowLeftIcon style={{ width: '16px', height: '16px' }} />
              Voltar
            </button>
          )}
          <div style={{ flex: 1 }} />
          {isLast ? (
            <button
              className="btn btn-primary"
              style={{ justifyContent: 'center' }}
              onClick={handleSubmit}
              disabled={saving}
            >
              {saving ? 'Salvando...' : (
                <><CheckCircleIcon style={{ width: '16px', height: '16px' }} /> Finalizar questionário</>
              )}
            </button>
          ) : (
            <button className="btn btn-primary" onClick={handleNext}>
              Próximo
              <ArrowRightIcon style={{ width: '16px', height: '16px' }} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
