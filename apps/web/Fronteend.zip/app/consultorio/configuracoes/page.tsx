'use client';
import { useEffect, useState } from 'react';
import { CheckCircleIcon, ClockIcon } from '@heroicons/react/24/outline';
import { apiFetch } from '../../lib/api';
import FaqHelp from '../../../components/FaqHelp';

interface ClinicData {
  name: string;
  cnpj: string;
  address: string;
  city: string;
  state: string;
  email: string;
  phone: string;
  contactEmail: string;
}

const formatCNPJ = (val: string) => {
  const clean = val.replace(/\D/g, '');
  return clean
    .replace(/^(\d{2})(\d)/, '$1.$2')
    .replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3')
    .replace(/\.(\d{3})(\d)/, '.$1/$2')
    .replace(/(\d{4})(\d)/, '$1-$2')
    .substring(0, 18);
};

export default function ConsultorioConfiguracoesPage() {
  const [clinicData, setClinicData] = useState<ClinicData>({
    name: '',
    cnpj: '',
    address: '',
    city: '',
    state: '',
    email: '',
    phone: '',
    contactEmail: '',
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [changingPassword, setChangingPassword] = useState(false);
  const [passwordChanged, setPasswordChanged] = useState(false);
  const [passwordError, setPasswordError] = useState('');

  useEffect(() => {
    setLoading(true);
    apiFetch('/api/clinic/profile')
      .then((result) => {
        if (result) {
          setClinicData({
            name: result.name ?? '',
            cnpj: formatCNPJ(result.cnpj ?? ''),
            address: result.address ?? '',
            city: result.city ?? '',
            state: result.state ?? '',
            email: result.email ?? '',
            phone: result.phone ?? '',
            contactEmail: result.contactEmail ?? '',
          });
        }
      })
      .catch(() => console.error('Erro ao carregar perfil da clínica'))
      .finally(() => setLoading(false));
  }, []);

  const handleSaveProfile = async () => {
    setSaving(true);
    try {
      const result = await apiFetch('/api/clinic/profile', {
        method: 'PATCH',
        body: JSON.stringify({
          name: clinicData.name,
          address: clinicData.address,
          city: clinicData.city,
          state: clinicData.state,
          phone: clinicData.phone,
          contactEmail: clinicData.contactEmail,
        }),
      });
      if (result.success) {
        setSaved(true);
        setTimeout(() => setSaved(false), 3000);
      } else {
        alert(result.message ?? 'Erro ao salvar');
      }
    } catch {
      alert('Erro de conexão com o servidor');
    } finally {
      setSaving(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setChangingPassword(true);
    try {
      const result = await apiFetch('/api/auth/change-password', {
        method: 'POST',
        body: JSON.stringify({
          currentPassword,
          newPassword,
        }),
      });
      if (result.success) {
        setPasswordChanged(true);
        setCurrentPassword('');
        setNewPassword('');
        setTimeout(() => setPasswordChanged(false), 3000);
      } else {
        setPasswordError(result.message ?? 'Erro ao alterar senha');
      }
    } catch {
      setPasswordError('Erro de conexão com o servidor');
    } finally {
      setChangingPassword(false);
    }
  };

  if (loading) {
    return (
      <div className="page-center">
        <p style={{ color: 'var(--text-muted)' }}>Carregando...</p>
      </div>
    );
  }

  return (
    <>
      <div className="page-header">
        <h2>Configurações da Clínica</h2>
        <p>Dados cadastrais e segurança</p>
      </div>

      <div className="card">
        <h3 style={{ fontSize: '16px', fontWeight: 600, color: '#1e1b4b', marginBottom: '16px' }}>
          Perfil da Clínica
        </h3>
        <div className="form-grid">
          <div className="form-group">
            <label className="form-label">Nome</label>
            <input
              type="text"
              className="form-input"
              value={clinicData.name}
              onChange={(e) => setClinicData({ ...clinicData, name: e.target.value })}
            />
          </div>
          <div className="form-group">
            <label className="form-label">CNPJ</label>
            <input
              type="text"
              className="form-input"
              value={clinicData.cnpj}
              disabled
              style={{ background: '#f9fafb', color: '#6b7280' }}
            />
          </div>
          <div className="form-group">
            <label className="form-label">E-mail</label>
            <input
              type="text"
              className="form-input"
              value={clinicData.email}
              disabled
              style={{ background: '#f9fafb', color: '#6b7280' }}
            />
          </div>
          <div className="form-group">
            <label className="form-label">Endereço</label>
            <input
              type="text"
              className="form-input"
              value={clinicData.address}
              onChange={(e) => setClinicData({ ...clinicData, address: e.target.value })}
            />
          </div>
          <div className="form-group">
            <label className="form-label">Telefone de Contato</label>
            <input
              type="text"
              className="form-input"
              value={clinicData.phone}
              onChange={(e) => setClinicData({ ...clinicData, phone: e.target.value })}
              placeholder="(00) 0000-0000"
            />
          </div>
          <div className="form-group">
            <label className="form-label">E-mail de Contato</label>
            <input
              type="email"
              className="form-input"
              value={clinicData.contactEmail}
              onChange={(e) => setClinicData({ ...clinicData, contactEmail: e.target.value })}
              placeholder="contato@clinica.com.br"
            />
          </div>
          <div className="form-group">
            <label className="form-label">Cidade</label>
            <input
              type="text"
              className="form-input"
              value={clinicData.city}
              onChange={(e) => setClinicData({ ...clinicData, city: e.target.value })}
            />
          </div>
          <div className="form-group">
            <label className="form-label">Estado</label>
            <select
              className="form-select"
              value={clinicData.state}
              onChange={(e) => setClinicData({ ...clinicData, state: e.target.value })}
            >
              <option value="">Selecione</option>
              {['AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN', 'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO'].map((u) => (
                <option key={u} value={u}>{u}</option>
              ))}
            </select>
          </div>
        </div>
        <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end', marginTop: '24px' }}>
          {saved && (
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', color: '#22c55e', fontSize: '13px', alignSelf: 'center' }}>
              <CheckCircleIcon className="icon icon-sm" />
              Salvo com sucesso!
            </span>
          )}
          <button className="btn btn-primary" onClick={handleSaveProfile} disabled={saving}>
            {saving ? <><ClockIcon className="icon" /> Salvando...</> : 'Salvar Alterações'}
          </button>
        </div>
      </div>

      <div className="card" style={{ marginTop: '24px' }}>
        <h3 style={{ fontSize: '16px', fontWeight: 600, color: '#1e1b4b', marginBottom: '16px' }}>
          Alterar Senha
        </h3>
        <form onSubmit={handleChangePassword}>
          <div className="form-grid">
            <div className="form-group">
              <label className="form-label">Senha Atual</label>
              <input
                type="password"
                className="form-input"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="Digite sua senha atual"
                required
              />
            </div>
            <div className="form-group">
              <label className="form-label">Nova Senha</label>
              <input
                type="password"
                className="form-input"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Digite a nova senha"
                minLength={6}
                required
              />
            </div>
          </div>
          {passwordError && <p style={{ color: '#dc2626', fontSize: '14px', marginTop: '12px' }}>{passwordError}</p>}
          {passwordChanged && (
            <p style={{ color: '#22c55e', fontSize: '14px', marginTop: '12px', display: 'flex', alignItems: 'center', gap: '6px' }}>
              <CheckCircleIcon className="icon icon-sm" />
              Senha alterada com sucesso!
            </p>
          )}
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '16px' }}>
            <button type="submit" className="btn btn-primary" disabled={changingPassword}>
              {changingPassword ? <><ClockIcon className="icon" /> Alterando...</> : 'Alterar Senha'}
            </button>
          </div>
        </form>
      </div>

      <FaqHelp perfil="CLINICA" />
    </>
  );
}