'use client';

import { useEffect, useState } from 'react';
import { ChevronDownIcon } from '@heroicons/react/24/outline';
import { useTour } from '@repo/ui/tour';
import type { FaqItem, TourPerfil } from '../lib/api';
import { apiGetTutorial } from '../lib/api';

export default function TutorialHelp({ perfil }: { perfil: TourPerfil }) {
  const { open } = useTour();
  const [faq, setFaq] = useState<FaqItem[]>([]);
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  useEffect(() => {
    apiGetTutorial(perfil)
      .then((t) => setFaq(t?.faq ?? []))
      .catch(() => setFaq([]));
  }, [perfil]);

  const handleReabrir = () => {
    open(0);
  };

  return (
    <div className="card" style={{ marginTop: 24 }}>
      <h3 style={{ fontSize: 16, fontWeight: 700, color: '#1e1b4b', marginBottom: 8 }}>
        Tutoriais e Dúvidas
      </h3>
      <p style={{ fontSize: 13, color: '#6b7280', marginBottom: 16 }}>
        Não lembra como usar a plataforma? Reassista o passeio inicial ou consulte as
        dúvidas abaixo.
      </p>

      <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
        <button
          className="btn btn-primary"
          onClick={handleReabrir}
        >
          Refazer tutorial de boas-vindas
        </button>
        <button
          className="btn"
          onClick={() => {
            // Limpa o progresso e reabre
            const userId = typeof window !== 'undefined' ? localStorage.getItem('ss_tour_uid') : null;
            if (userId) {
              fetch(`${process.env.NEXT_PUBLIC_BACKEND_URL ?? 'http://localhost:3001'}/api/tutorials/${perfil}/progress?userId=${encodeURIComponent(userId)}`, {
                method: 'DELETE',
              }).then(() => {
                alert('Progresso limpo! O tutorial será reaberto.');
                open(0);
              }).catch(() => {
                alert('Erro ao limpar progresso, mas você pode reassistir mesmo assim.');
                open(0);
              });
            } else {
              open(0);
            }
          }}
          style={{ background: '#f3f4f6', color: '#374151' }}
        >
          Limpar progresso e reabrir
        </button>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {faq.map((item, i) => (
          <div
            key={i}
            style={{
              border: '1px solid #e5e7eb',
              borderRadius: 12,
              overflow: 'hidden',
            }}
          >
            <button
              onClick={() => setOpenIdx(openIdx === i ? null : i)}
              style={{
                width: '100%',
                textAlign: 'left',
                padding: '12px 16px',
                background: '#fff',
                border: 'none',
                cursor: 'pointer',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                fontSize: 14,
                fontWeight: 600,
                color: '#1e1b4b',
              }}
            >
              {item.pergunta}
              <ChevronDownIcon
                style={{
                  width: 16,
                  height: 16,
                  transform: openIdx === i ? 'rotate(180deg)' : 'none',
                  transition: 'transform .2s',
                }}
              />
            </button>
            {openIdx === i && (
              <div
                style={{
                  padding: '0 16px 14px',
                  fontSize: 13,
                  color: '#374151',
                  lineHeight: 1.5,
                }}
              >
                {item.resposta}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
