'use client';

import { useEffect, useRef, useState } from 'react';
import { TourProvider, useTour } from '@repo/ui/tour';
import type { Tutorial, TourPerfil } from '../lib/api';
import { apiGetTutorial, apiGetTutorialProgress, apiMarkTutorialProgress } from '../lib/api';
import { getLocalUserId } from '../lib/tourUser';

async function markProgress(perfil: TourPerfil, skipped: boolean) {
  try {
    await apiMarkTutorialProgress(perfil, getLocalUserId(), skipped);
  } catch {
    /* falha silenciosa — não bloqueia o uso */
  }
}

function TourAutoOpen({ perfil }: { perfil: TourPerfil }) {
  const { tutorial, open } = useTour();
  const checked = useRef(false);

  useEffect(() => {
    if (!tutorial || checked.current) return;
    let cancelled = false;
    console.log('[TourAutoOpen] Tutorial carregado, verificando progresso...', perfil);
    (async () => {
      const userId = getLocalUserId();
      console.log('[TourAutoOpen] User ID:', userId);
      const prog = await apiGetTutorialProgress(perfil, userId);
      console.log('[TourAutoOpen] Progresso COMPLETO:', JSON.stringify(prog));
      if (cancelled || prog.completed || checked.current) {
        console.log('[TourAutoOpen] Não abre. completed=', prog.completed, 'checked=', checked.current);
        return;
      }
      checked.current = true;
      console.log('[TourAutoOpen] Abrindo tour no passo 0');
      setTimeout(() => {
        if (!cancelled) open(0);
      }, 800);
    })();
    return () => {
      cancelled = true;
    };
  }, [tutorial, perfil, open]);

  return null;
}

export default function TutorialTour({
  perfil,
  children,
}: {
  perfil: TourPerfil;
  children: React.ReactNode;
}) {
  const [tutorial, setTutorial] = useState<Tutorial | null>(null);

  useEffect(() => {
    console.log('[TutorialTour] Buscando tutorial para:', perfil);
    apiGetTutorial(perfil)
      .then((t) => {
        console.log('[TutorialTour] Tutorial recebido:', t ? t.id : 'null');
        setTutorial(t);
      })
      .catch((e) => {
        console.error('[TutorialTour] Erro ao buscar tutorial:', e);
        setTutorial(null);
      });
  }, [perfil]);

  return (
    <TourProvider tutorial={tutorial} onComplete={(skipped) => markProgress(perfil, skipped)}>
      <TourAutoOpen perfil={perfil} />
      {children}
    </TourProvider>
  );
}
