'use client';

import TutorialHelp from '../../../components/TutorialHelp';

export default function ConsultorioConfiguracoesPage() {
  return (
    <>
      <div className="page-header">
        <h2>Configurações da Clínica</h2>
        <p>Preferências e suporte da clínica</p>
      </div>

      <TutorialHelp perfil="CLINICA" />
    </>
  );
}
