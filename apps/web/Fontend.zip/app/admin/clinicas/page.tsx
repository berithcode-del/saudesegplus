'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { ArrowPathIcon, PlusIcon, XMarkIcon } from '@heroicons/react/24/outline';
import { apiAdminListClinics, apiAdminCreateClinic } from '../../../app/lib/api';

interface Clinic {
  id: string;
  name: string;
  city: string;
  state: string;
  capacity?: number;
}

export default function AdminClinicasPage() {
  const [clinics, setClinics] = useState<Clinic[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: '', cnpj: '', city: '', state: '', capacity: '' });
  const [saving, setSaving] = useState(false);

  const fetchClinics = async () => {
    setLoading(true);
    try {
      const r = await apiAdminListClinics();
      setClinics(Array.isArray(r.data) ? r.data : []);
    } catch { setClinics([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchClinics(); }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await apiAdminCreateClinic({ ...form, capacity: form.capacity ? Number(form.capacity) : undefined });
      setShowForm(false);
      setForm({ name: '', city: '', state: '', capacity: '' });
      await fetchClinics();
    } catch { alert('Erro ao cadastrar clínica.'); }
    finally { setSaving(false); }
  };

  return (
    <>
      <div className="page-header">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h2>Clínicas</h2>
            <p>Gerencie as clínicas credenciadas</p>
          </div>
          <button className="btn btn-primary" onClick={() => setShowForm(true)}>
            <PlusIcon className="icon" /> Nova Clínica
          </button>
        </div>
      </div>

      {showForm && (
        <div className="modal-overlay" onClick={() => setShowForm(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Cadastrar Clínica</h3>
              <button className="modal-close" onClick={() => setShowForm(false)}><XMarkIcon className="icon" /></button>
            </div>
            <form onSubmit={handleCreate}>
              <div className="form-grid">
                <div className="form-group">
                  <label className="form-label">Nome *</label>
                  <input className="form-input" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required />
                </div>
                <div className="form-group">
                  <label className="form-label">CNPJ *</label>
                  <input className="form-input" value={form.cnpj} onChange={e => setForm({ ...form, cnpj: e.target.value })} placeholder="00.000.000/0000-00" required />
                </div>
                <div className="form-group">
                  <label className="form-label">Cidade *</label>
                  <input className="form-input" value={form.city} onChange={e => setForm({ ...form, city: e.target.value })} required />
                </div>
                <div className="form-group">
                  <label className="form-label">Estado *</label>
                  <select className="form-select" value={form.state} onChange={e => setForm({ ...form, state: e.target.value })} required>
                    <option value="">Selecione</option>
                    {['AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO'].map(u => (
                      <option key={u} value={u}>{u}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end', marginTop: '20px' }}>
                <button type="button" className="btn btn-ghost" onClick={() => setShowForm(false)}>Cancelar</button>
                <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Salvando...' : 'Salvar'}</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="card">
        {loading ? (
          <p style={{ color: 'var(--text-muted)', textAlign: 'center', padding: '40px' }}>Carregando...</p>
        ) : clinics.length === 0 ? (
          <p style={{ color: 'var(--text-muted)', textAlign: 'center', padding: '40px' }}>Nenhuma clínica cadastrada.</p>
        ) : (
          <table className="queue-table">
            <thead>
              <tr><th>Nome</th><th>Cidade</th><th>Estado</th><th>CNPJ</th><th>Empresas</th><th>Ações</th></tr>
            </thead>
            <tbody>
              {clinics.map(c => (
                <tr key={c.id}>
                  <td style={{ fontWeight: 600 }}>{c.name}</td>
                  <td>{c.city}</td>
                  <td>{c.state}</td>
                  <td>{(c as any).cnpj ?? '—'}</td>
                  <td>{(c as any).companies?.length ?? 0}</td>
                  <td>
                    <Link href={`/admin/clinicas/${c.id}`} className="btn btn-primary" style={{ padding: '4px 10px', fontSize: '12px', textDecoration: 'none' }}>
                      Ver perfil
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
