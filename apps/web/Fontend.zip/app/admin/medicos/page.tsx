'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { ArrowPathIcon, PlusIcon, CheckIcon, TrashIcon } from '@heroicons/react/24/outline';
import { apiAdminListDoctors, apiAdminCreateDoctor, apiAdminVerifyDoctor } from '../../../app/lib/api';

interface Doctor {
  id: string;
  name: string;
  crmNumber: string;
  crmState: string;
  city?: string;
  state?: string;
  specialties?: string;
  verifiedAt?: string | null;
}

export default function AdminMedicosPage() {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [form, setForm] = useState({ name: '', crmNumber: '', crmState: '', city: '', state: '', specialties: '' });

  const fetchDoctors = async () => {
    setLoading(true);
    try {
      const r = await apiAdminListDoctors();
      setDoctors(Array.isArray(r.data) ? r.data : []);
    } catch { setDoctors([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchDoctors(); }, []);

  const handleVerify = async (id: string) => {
    try {
      await apiAdminVerifyDoctor(id);
      await fetchDoctors();
    } catch (err) {
      alert('Erro ao verificar médico');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.crmNumber.trim() || !form.crmState.trim()) {
      setError('Preencha nome, CRM e estado do CRM.');
      return;
    }
    setSaving(true);
    setError('');
    try {
      await apiAdminCreateDoctor({
        name: form.name.trim(),
        crmNumber: form.crmNumber.trim(),
        crmState: form.crmState.trim().toUpperCase(),
        city: form.city.trim() || undefined,
        state: form.state.trim() || undefined,
        specialties: form.specialties.trim() || undefined,
      });
      setShowModal(false);
      setForm({ name: '', crmNumber: '', crmState: '', city: '', state: '', specialties: '' });
      await fetchDoctors();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Erro ao cadastrar médico');
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <div className="page-header">
        <h2>Médicos</h2>
        <p>Gerencie os médicos cadastrados na plataforma</p>
      </div>
      <div className="card">
        <div style={{ display: 'flex', gap: '12px', marginBottom: '16px' }}>
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>
            <PlusIcon className="icon icon-sm" /> Novo Médico
          </button>
          <button className="btn btn-ghost" onClick={fetchDoctors}><ArrowPathIcon className="icon icon-sm" /> Atualizar</button>
        </div>
        {loading ? (
          <p style={{ color: 'var(--text-muted)', textAlign: 'center', padding: '40px' }}>Carregando...</p>
        ) : doctors.length === 0 ? (
          <p style={{ color: 'var(--text-muted)', textAlign: 'center', padding: '40px' }}>Nenhum médico cadastrado.</p>
        ) : (
          <table className="queue-table">
            <thead>
              <tr><th>Nome</th><th>CRM</th><th>Estado</th><th>Cidade</th><th>Especialidades</th><th>Status</th><th>Ações</th></tr>
            </thead>
            <tbody>
              {doctors.map(d => {
                const isVerified = !!d.verifiedAt;
                return (
                  <tr key={d.id}>
                    <td style={{ fontWeight: 600 }}>{d.name}</td>
                    <td>{d.crmNumber}/{d.crmState}</td>
                    <td>{d.state ?? '—'}</td>
                    <td>{d.city ?? '—'}</td>
                    <td>{d.specialties ?? '—'}</td>
                    <td>
                      <span style={{ color: isVerified ? '#16a34a' : '#d97706', fontWeight: 600, fontSize: '13px' }}>
                        {isVerified ? 'Verificado' : 'Pendente'}
                      </span>
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <Link href={`/admin/medicos/${d.id}`} className="btn btn-primary" style={{ padding: '4px 10px', fontSize: '12px', textDecoration: 'none' }}>Ver perfil</Link>
                        {!isVerified && (
                          <button
                            className="btn btn-success"
                            style={{ padding: '4px 8px', fontSize: '12px', gap: '4px' }}
                            onClick={() => handleVerify(d.id)}
                          >
                            <CheckIcon style={{ width: '14px', height: '14px' }} />
                            Aprovar
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <h3>Novo Médico</h3>
            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginTop: '16px' }}>
              <div>
                <label className="input-label">Nome *</label>
                <input className="input" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} placeholder="Nome completo" />
              </div>
              <div style={{ display: 'flex', gap: '8px' }}>
                <div style={{ flex: 2 }}>
                  <label className="input-label">CRM *</label>
                  <input className="input" value={form.crmNumber} onChange={e => setForm(p => ({ ...p, crmNumber: e.target.value }))} placeholder="Número do CRM" />
                </div>
                <div style={{ flex: 1 }}>
                  <label className="input-label">Estado CRM *</label>
                  <input className="input" value={form.crmState} onChange={e => setForm(p => ({ ...p, crmState: e.target.value }))} placeholder="SP" maxLength={2} />
                </div>
              </div>
              <div style={{ display: 'flex', gap: '8px' }}>
                <div style={{ flex: 1 }}>
                  <label className="input-label">Cidade</label>
                  <input className="input" value={form.city} onChange={e => setForm(p => ({ ...p, city: e.target.value }))} placeholder="Cidade" />
                </div>
                <div style={{ flex: 1 }}>
                  <label className="input-label">Estado</label>
                  <input className="input" value={form.state} onChange={e => setForm(p => ({ ...p, state: e.target.value }))} placeholder="UF" maxLength={2} />
                </div>
              </div>
              <div>
                <label className="input-label">Especialidades</label>
                <input className="input" value={form.specialties} onChange={e => setForm(p => ({ ...p, specialties: e.target.value }))} placeholder="Ex: Medicina do Trabalho" />
              </div>
              {error && <p style={{ color: '#dc2626', fontSize: '14px' }}>{error}</p>}
              <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end', marginTop: '8px' }}>
                <button type="button" className="btn btn-ghost" onClick={() => setShowModal(false)}>Cancelar</button>
                <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Salvando...' : 'Salvar'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
