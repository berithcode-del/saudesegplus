import type { TourPerfil, Tutorial } from './api';

const map: Record<TourPerfil, Omit<Tutorial, 'id' | 'perfil' | 'ativo'>> = {
  EMPRESA: {
    titulo: 'Bem-vindo à SaudeSeg+',
    steps: [
      {
        id: 'boas-vindas',
        titulo: '👋 Bem-vindo ao Portal da Empresa!',
        texto: 'Estamos felizes em tê-lo aqui! Este é um rápido tour de boas-vindas para te ajudar a conhecer as principais funcionalidades da plataforma. Você pode navegar pelos passos ou pular a qualquer momento.',
        // Sem anchorSelector = Modal Central de Boas-Vindas
        posicao: 'bottom',
        route: '/empresa',
      },
      {
        id: 'painel',
        titulo: 'Seu Painel',
        texto: 'Aqui você acompanha os indicadores em tempo real: total de exames, colaboradores ativos e pendências.',
        anchorSelector: "[data-tour='painel']",
        posicao: 'right',
        route: '/empresa',
      },
      {
        id: 'colaboradores',
        titulo: 'Colaboradores',
        texto: 'Gerencie sua equipe e envie convites para que novos colaboradores realizem seus exames.',
        anchorSelector: "[data-tour='colaboradores']",
        posicao: 'bottom',
        route: '/empresa',
      },
      {
        id: 'solicitacoes',
        titulo: 'Solicitações de Exame',
        texto: 'Crie e acompanhe as solicitações de exames ocupacionais de cada colaborador.',
        anchorSelector: "[data-tour='solicitacoes']",
        posicao: 'bottom',
        route: '/empresa/solicitacoes',
      },
      {
        id: 'configuracoes',
        titulo: 'Configurações',
        texto: 'Ajuste os dados cadastrais da empresa, suba os documentos obrigatórios (PCMSO, PPRA) e configure as preferências da conta.',
        anchorSelector: "[data-tour='configuracoes']",
        posicao: 'left',
        route: '/empresa/configuracoes',
      },
    ],
    faq: [
      { pergunta: 'Como convido um novo colaborador?', resposta: 'Acesse a aba Colaboradores e clique em "Enviar convite", informando os dados do colaborador.' },
      { pergunta: 'Como acompanho os exames pendentes?', resposta: 'Na aba Solicitações de exame você vê o status de cada exame e pode filtrar por pendentes.' },
      { pergunta: 'Onde subo os documentos da empresa?', resposta: 'Em Configurações → Documentos, você pode enviar o PCMSO, PPRA e outros documentos obrigatórios.' },
    ],
  },
  CLINICA: {
    titulo: 'Bem-vindo à SaudeSeg+',
    steps: [
      {
        id: 'boas-vindas',
        titulo: '🏥 Bem-vindo ao Portal da Clínica!',
        texto: 'Este tour vai te guiar pelas principais funcionalidades da plataforma. Você pode navegar pelos passos ou pular a qualquer momento.',
        posicao: 'bottom',
        route: '/consultorio',
      },
      {
        id: 'checkin',
        titulo: 'Check-in de Pacientes',
        texto: 'Registre a chegada dos pacientes e dê início ao fluxo de atendimento pela fila.',
        anchorSelector: "[data-tour='checkin']",
        posicao: 'right',
        route: '/consultorio',
      },
      {
        id: 'pacientes',
        titulo: 'Pacientes',
        texto: 'Visualize o histórico clínico e os dados de todos os pacientes atendidos na clínica.',
        anchorSelector: "[data-tour='pacientes']",
        posicao: 'bottom',
        route: '/consultorio/pacientes',
      },
      {
        id: 'financeiro',
        titulo: 'Financeiro',
        texto: 'Acompanhe os repasses e o faturamento da clínica em tempo real.',
        anchorSelector: "[data-tour='financeiro']",
        posicao: 'left',
        route: '/consultorio/financeiro',
      },
    ],
    faq: [
      { pergunta: 'Como registro a chegada de um paciente?', resposta: 'Na aba Check-in, localize o paciente pela solicitação e confirme a entrada.' },
      { pergunta: 'Onde vejo meus repasses financeiros?', resposta: 'A aba Financeiro exibe os repasses pendentes e já realizados para a clínica.' },
    ],
  },
  MEDICO: {
    titulo: 'Bem-vindo à SaudeSeg+',
    steps: [
      {
        id: 'boas-vindas',
        titulo: '👨‍⚕️ Bem-vindo, Médico!',
        texto: 'Seja bem-vindo ao painel médico da SaudeSeg+! Vamos te mostrar como realizar teleconsultas, emitir ASOs e gerenciar suas disponibilidades.',
        posicao: 'bottom',
        route: '/medico',
      },
      {
        id: 'fila',
        titulo: 'Fila de Atendimento',
        texto: 'Aqui você vê os pacientes aguardando teleconsulta. Aceite um paciente para iniciar o atendimento.',
        anchorSelector: "[data-tour='fila']",
        posicao: 'right',
        route: '/medico',
      },
      {
        id: 'historico',
        titulo: 'Histórico do Paciente',
        texto: 'Acesse o histórico ocupacional e clínico completo de cada paciente antes de iniciar a consulta.',
        anchorSelector: "[data-tour='historico']",
        posicao: 'bottom',
        route: '/medico',
      },
      {
        id: 'configuracao',
        titulo: 'Suas Configurações',
        texto: 'Ajuste sua disponibilidade de horários, dados profissionais e preferências de notificação.',
        anchorSelector: "[data-tour='configuracao']",
        posicao: 'left',
        route: '/medico/configuracao',
      },
    ],
    faq: [
      { pergunta: 'Como inicio uma teleconsulta?', resposta: 'Na Fila de atendimento, selecione o paciente e clique em "Iniciar consulta".' },
      { pergunta: 'Onde registro o ASO?', resposta: 'Durante a consulta, use a aba de documentos para emitir e assinar o ASO.' },
      { pergunta: 'Como altero minha disponibilidade?', resposta: 'Em Configurações → Agenda, você pode definir os horários em que está disponível para atendimento.' },
    ],
  },
};

export function defaultTutorial(perfil: TourPerfil): Tutorial {
  const conteudo = map[perfil];
  return {
    id: `default-${perfil.toLowerCase()}`,
    perfil,
    ativo: true,
    ...conteudo,
  };
}
