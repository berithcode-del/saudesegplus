const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL ?? 'http://localhost:3001';

import { defaultTutorial } from './tutorialDefaults';

export async function apiGetExamTypes(): Promise<{ data: any }> {
  const res = await fetch(`${BACKEND_URL}/api/exams/types`);
  return res.json();
}

export async function apiGetRequiredExams(cboCode: string): Promise<{ data: any }> {
  const res = await fetch(`${BACKEND_URL}/api/exams/required-by-cbo?cbo=${encodeURIComponent(cboCode)}`);
  return res.json();
}

export async function apiGetMedicoProfile(id: string): Promise<{ data: any }> {
  const res = await fetch(`${BACKEND_URL}/api/medicos/${id}/perfil`);
  return res.json();
}

export async function apiGetMedicoSolicitacoes(id: string, startDate?: string, endDate?: string): Promise<{ data: any }> {
  let url = `${BACKEND_URL}/api/medicos/${id}/solicitacoes`;
  const params = new URLSearchParams();
  if (startDate) params.append('startDate', startDate);
  if (endDate) params.append('endDate', endDate);
  
  if (params.toString()) {
    url += `?${params.toString()}`;
  }
  
  const res = await fetch(url);
  return res.json();
}

export async function apiGetEvents(ownerType: string, ownerId: string, startDate?: string, endDate?: string) {
  const params = new URLSearchParams({ ownerType, ownerId });
  if (startDate) params.append('startDate', startDate);
  if (endDate) params.append('endDate', endDate);
  
  const response = await fetch(`${BACKEND_URL}/api/calendar?${params.toString()}`);
  if (!response.ok) throw new Error('Falha ao buscar eventos de calendário');
  const data = await response.json();
  return data.data || [];
}

export async function apiCreateEvent(payload: { title: string; type: string; date: string; ownerType: string; ownerId: string }) {
  const response = await fetch(`${BACKEND_URL}/api/calendar`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!response.ok) throw new Error('Falha ao criar evento no calendário');
  const data = await response.json();
  return data.data;
}

export async function apiFetch(endpoint: string, options: RequestInit = {}) {
  const url = endpoint.startsWith('http') ? endpoint : `${BACKEND_URL}${endpoint}`;
  const res = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
  });
  if (!res.ok) throw new Error(`Erro na chamada da API: ${res.statusText}`);
  return res.json();
}

export async function apiGetQueue(doctorId: string) {
  return apiFetch(`/api/queue?doctorId=${encodeURIComponent(doctorId)}`);
}

export async function apiAcceptPatient(examRequestId: string, doctorId: string) {
  return apiFetch(`/api/queue/accept`, {
    method: 'POST',
    body: JSON.stringify({ examRequestId, doctorId }),
  });
}

export async function apiGetSolicitacao(id: string) {
  return apiFetch(`/api/solicitacoes/${id}`);
}

export async function apiUpdateSolicitacao(id: string, data: any) {
  return apiFetch(`/api/solicitacoes/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(data),
  });
}

export async function apiCreateVideoRoom(examRequestId: string, doctorId: string) {
  return apiFetch(`/api/teleconsultation/create-room`, {
    method: 'POST',
    body: JSON.stringify({ examRequestId, doctorId }),
  });
}

// ─── Tutoriais / Product Tour ────────────────────────────────────────────────

export type TourPerfil = 'EMPRESA' | 'CLINICA' | 'MEDICO';
export type TourPosicao = 'top' | 'bottom' | 'left' | 'right';

export interface TourStep {
  id: string;
  titulo: string;
  texto: string;
  anchorSelector?: string; // Optional — if absent, step renders as centered modal
  posicao: TourPosicao;
  route?: string;   // Optional — navigate to this page before showing step
  image?: string;   // Optional — illustration URL shown inside the modal
}

export interface FaqItem {
  pergunta: string;
  resposta: string;
}

export interface Tutorial {
  id: string;
  perfil: TourPerfil;
  titulo: string;
  steps: TourStep[];
  faq: FaqItem[];
  ativo: boolean;
}

export async function apiGetTutorial(perfil: TourPerfil): Promise<Tutorial | null> {
  try {
    const res = await fetch(`${BACKEND_URL}/api/tutorials/${perfil}`);
    const json = await res.json();
    if (json.success && json.data) return json.data as Tutorial;
  } catch {
    /* backend indisponível — usa fallback local */
  }
  return defaultTutorial(perfil);
}

export async function apiGetTutorialProgress(
  perfil: TourPerfil,
  userId: string,
): Promise<{ completed: boolean; skipped: boolean }> {
  try {
    const res = await fetch(
      `${BACKEND_URL}/api/tutorials/${perfil}/progress?userId=${encodeURIComponent(userId)}`,
    );
    const json = await res.json();
    if (json.success) return json.data;
  } catch {
    /* backend indisponível — trata como não concluído */
  }
  return { completed: false, skipped: false };
}

export async function apiMarkTutorialProgress(
  perfil: TourPerfil,
  userId: string,
  skipped: boolean,
): Promise<void> {
  try {
    await fetch(`${BACKEND_URL}/api/tutorials/${perfil}/progress`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, skipped }),
    });
  } catch {
    /* falha silenciosa — não bloqueia o uso */
  }
}
