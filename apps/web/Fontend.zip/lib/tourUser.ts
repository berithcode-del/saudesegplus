const STORAGE_KEY = 'ss_tour_uid';

/**
 * Retorna um id de usuário estável por navegador para vincular o progresso
 * do tutorial (a plataforma ainda não tem auth por usuário implementada).
 */
export function getLocalUserId(): string {
  if (typeof window === 'undefined') return 'anon';
  let id = window.localStorage.getItem(STORAGE_KEY);
  if (!id) {
    id = 'u_' + Math.random().toString(36).slice(2) + Date.now().toString(36);
    window.localStorage.setItem(STORAGE_KEY, id);
  }
  return id;
}
